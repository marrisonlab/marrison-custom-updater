<?php
namespace App\Services;

use App\Models\Settings;
use DateTimeImmutable;
use DateTimeZone;

/** Wall-clock daily schedule; independent from visits to the WordPress sites. */
class MaintenanceVerificationSchedule
{
    public static function configuration(): array
    {
        $time = (string) Settings::get('maintenance_verification_time', '03:00');
        return [
            'enabled' => Settings::get('maintenance_verification_enabled', '1') === '1',
            'time' => self::validTime($time) ? $time : '03:00',
        ];
    }

    public static function validTime(string $time): bool
    {
        return preg_match('/^(?:[01][0-9]|2[0-3]):[0-5][0-9]$/', $time) === 1;
    }

    public static function dueAt(int $siteId, ?int $now = null, bool $next = false): string
    {
        $now ??= time();
        $local = (new DateTimeImmutable('@' . $now))->setTimezone(new DateTimeZone('Europe/Rome'));
        [$hour, $minute] = array_map('intval', explode(':', self::configuration()['time']));
        $target = $local->setTime($hour, $minute);
        // Spread sites over 15 minutes without moving their daily wall-clock time.
        $offset = (int) sprintf('%u', crc32((string) $siteId)) % 901;
        $target = $target->modify('+' . $offset . ' seconds');
        if ($next && $target->getTimestamp() <= $now) {
            $target = $local->modify('+1 day')->setTime($hour, $minute)->modify('+' . $offset . ' seconds');
        }
        return $target->setTimezone(new DateTimeZone(date_default_timezone_get()))->format('Y-m-d H:i:s');
    }
}
