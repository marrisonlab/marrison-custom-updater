<?php

namespace App\Services;

use App\Models\Settings;

/**
 * Signed HTTP client for MCU maintenance endpoints.
 */
class MaintenanceHttpClient
{
    public const VERSION = '1.5.12';
    public const STATUS_REST_PATH = '/marrison-maintenance/v1/status';
    public const ACTION_REST_PATH = '/marrison-maintenance/v1/action';
    public const DEBUG_LOG_REST_PATH = '/marrison-maintenance/v1/debug-log';
    public const DASHBOARD_ACCESS_REST_PATH = '/marrison-maintenance/v1/dashboard-access';
    public const COMMANDER_JOB_CALLBACK_PATH = '/marrison-commander/v1/maintenance-job-callback';

    /** An explicit update verification always refreshes every update source first. */
    public static function verifyUpdates(array $site): array
    {
        $sync = self::requestForceSync($site);
        if (empty($sync['success'])) {
            $sync['status'] = 'failed';
            $sync['error_type'] = (string) ($sync['error_type'] ?? '') ?: 'update_sync_failed';
            $sync['error_message'] = (string) ($sync['error_message'] ?? '') ?: 'Sincronizzazione aggiornamenti non riuscita.';
            return $sync;
        }
        $check = self::check($site);
        $check['success'] = ($check['status'] ?? 'failed') !== 'failed';
        $check['message'] = $check['success'] ? 'Verifica con sincronizzazione forzata completata.' : $check['error_message'];
        $check['diagnostics']['forced_update_sync'] = true;
        return $check;
    }

    public static function check(array $site, ?array $repositoryConfig = null): array
    {
        $start = microtime(true);
        $siteId = (int) ($site['id'] ?? 0);
        $endpoint = (string) ($site['endpoint_url'] ?? '');
        $timeout = self::timeout($site);
        $secret = MaintenanceSecretVault::decrypt((string) ($site['secret_encrypted'] ?? ''));
        $diagnostics = self::baseDiagnostics($endpoint, self::STATUS_REST_PATH, $timeout);

        if ($secret === '') {
            return self::result('failed', 0, self::durationMs($start), 'missing_secret', 'Stored connection key could not be decrypted.', [], $diagnostics);
        }

        $timestamp = (string) time();
        $nonce = self::nonce();
        $body = self::json([
            'site_id' => (string) $siteId,
            'master_url' => self::masterUrl(),
            'master_time' => (int) $timestamp,
            'protocol_v' => 1,
            'repository_config' => $repositoryConfig === null ? Settings::getMcuRepositoryConfig() : $repositoryConfig,
        ]);
        $headers = self::signedHeaders($siteId, $timestamp, $nonce, self::STATUS_REST_PATH, $body, $secret);
        $response = self::postJson($endpoint, $headers, $body, $timeout, $diagnostics, $start);

        if (!empty($response['transport_error'])) {
            return self::result(
                'failed',
                0,
                (int) $response['duration_ms'],
                self::classifyTransportError((string) $response['transport_error']),
                self::publicErrorMessage(self::classifyTransportError((string) $response['transport_error']), 0),
                [],
                $response['diagnostics']
            );
        }

        $httpCode = (int) $response['http_code'];
        $decoded = json_decode((string) $response['body'], true);
        $decodedSafe = json_last_error() === JSON_ERROR_NONE && is_array($decoded)
            ? self::redactSensitiveValue($decoded)
            : null;

        $diagnostics = $response['diagnostics'];
        if (is_array($decodedSafe)) {
            $diagnostics['response_json'] = $decodedSafe;
        }
        if (is_array($decoded) && isset($decoded['current_timestamp'])) {
            $diagnostics['time_skew_seconds'] = (int) $decoded['current_timestamp'] - time();
        }

        if ($httpCode === 200 && is_array($decodedSafe) && !empty($decodedSafe['success'])) {
            try {
                MaintenanceSnapshotSyncService::syncManifestFromStatus($site, $decodedSafe);
            } catch (\Throwable $e) {
                $diagnostics['snapshot_sync_error'] = self::text($e->getMessage());
            }

            $updates = self::updatesCount($decodedSafe);
            $masterUpdateStatus = '';
            if (isset($decodedSafe['mcu_master_update_status']) && is_array($decodedSafe['mcu_master_update_status'])) {
                $masterUpdateStatus = self::sanitizeKey((string) ($decodedSafe['mcu_master_update_status']['status'] ?? ''));
            }
            $status = in_array($masterUpdateStatus, ['queued', 'running'], true)
                ? 'pending'
                : ($updates > 0 ? 'updates' : 'ok');

            if ($status === 'ok' && !empty($decodedSafe['updates_may_be_stale'])) {
                return self::result('failed', $httpCode, (int) $response['duration_ms'], 'updates_not_verified',
                    'Dati aggiornamenti non verificati: eseguire una sincronizzazione forzata.', $decodedSafe, $diagnostics);
            }

            return self::result($status, $httpCode, (int) $response['duration_ms'], '', '', $decodedSafe, $diagnostics);
        }

        if ($httpCode === 200 && !is_array($decodedSafe)) {
            return self::result('failed', $httpCode, (int) $response['duration_ms'], 'invalid_json', 'The Client returned invalid JSON.', [], $diagnostics);
        }

        $errorType = self::classifyHttpResponse($httpCode, is_array($decodedSafe) ? $decodedSafe : [], $diagnostics);
        return self::result(
            'failed',
            $httpCode,
            (int) $response['duration_ms'],
            $errorType,
            self::publicErrorMessage($errorType, $httpCode),
            is_array($decodedSafe) ? $decodedSafe : [],
            $diagnostics
        );
    }

    public static function requestOperation(array $site, string $operation, array $parameters = [], ?int $timeoutOverride = null, ?array $repositoryConfig = null): array
    {
        $start = microtime(true);
        $siteId = (int) ($site['id'] ?? 0);
        $endpoint = self::actionEndpoint((string) ($site['endpoint_url'] ?? ''));
        $timeout = $timeoutOverride === null ? self::timeout($site) : max(3, min(300, $timeoutOverride));
        $secret = MaintenanceSecretVault::decrypt((string) ($site['secret_encrypted'] ?? ''));
        $diagnostics = self::baseDiagnostics($endpoint, self::ACTION_REST_PATH, $timeout);
        $operation = self::sanitizeKey($operation);
        $diagnostics['operation'] = $operation;
        $diagnostics['protocol_v'] = 2;

        if ($secret === '') {
            return self::result('failed', 0, self::durationMs($start), 'missing_secret', 'Stored connection key could not be decrypted.', [], $diagnostics);
        }

        $timestamp = (string) time();
        $nonce = self::nonce();
        $body = self::json([
            'site_id' => (string) $siteId,
            'master_url' => self::masterUrl(),
            'master_time' => (int) $timestamp,
            'protocol_v' => 2,
            'operation' => $operation,
            'parameters' => self::safeOperationParameters($parameters),
            'repository_config' => $repositoryConfig === null ? Settings::getMcuRepositoryConfig() : $repositoryConfig,
        ]);
        $headers = self::signedHeaders($siteId, $timestamp, $nonce, self::ACTION_REST_PATH, $body, $secret);
        $response = self::postJson($endpoint, $headers, $body, $timeout, $diagnostics, $start);

        if (!empty($response['transport_error'])) {
            $errorType = self::classifyTransportError((string) $response['transport_error']);
            return [
                'status' => 'failed',
                'success' => false,
                'http_code' => 0,
                'duration_ms' => (int) $response['duration_ms'],
                'error_type' => $errorType,
                'message' => '',
                'error_message' => (string) $response['transport_error'],
                'response_data' => [],
                'diagnostics' => $response['diagnostics'],
            ];
        }

        $decoded = json_decode((string) $response['body'], true);
        $decodedSafe = is_array($decoded) ? self::redactSensitiveValue($decoded) : [];
        $decodedData = isset($decodedSafe['data']) && is_array($decodedSafe['data']) ? $decodedSafe['data'] : [];
        $success = (int) $response['http_code'] === 200 && is_array($decoded) && !empty($decoded['success']);
        $message = '';
        if ($success && isset($decodedData['message']) && trim((string) $decodedData['message']) !== '') {
            $message = self::text((string) $decodedData['message']);
        } elseif (!$success && isset($decodedSafe['message']) && trim((string) $decodedSafe['message']) !== '') {
            $message = self::text((string) $decodedSafe['message']);
        }
        $errorType = '';
        if (!$success) {
            $errorType = isset($decodedSafe['error_code'])
                ? self::sanitizeKey((string) $decodedSafe['error_code'])
                : self::classifyHttpResponse((int) $response['http_code'], is_array($decodedSafe) ? $decodedSafe : [], $response['diagnostics'] ?? []);
        }

        $diagnostics = $response['diagnostics'];
        $diagnostics['response'] = $decodedSafe;

        return [
            'status' => $success ? 'ok' : 'failed',
            'success' => $success,
            'http_code' => (int) $response['http_code'],
            'duration_ms' => (int) $response['duration_ms'],
            'error_type' => $errorType,
            'message' => $message,
            'error_message' => $success ? '' : ($message !== '' ? $message : self::publicErrorMessage($errorType, (int) $response['http_code'])),
            'response_data' => is_array($decodedSafe) ? $decodedSafe : [],
            'diagnostics' => $diagnostics,
        ];
    }

    public static function requestUpdate(array $site): array
    {
        $parameters = [];
        $callbackUrl = self::jobCallbackUrl();
        if ($callbackUrl !== '') {
            $parameters = [
                'callback_url' => $callbackUrl,
                'callback_path' => self::COMMANDER_JOB_CALLBACK_PATH,
            ];
        }

        $result = self::requestOperation($site, 'update_all', $parameters);
        $success = !empty($result['success']);
        $message = $success && trim((string) ($result['message'] ?? '')) !== ''
            ? (string) $result['message']
            : 'Richiesta aggiornamento inviata.';

        $result['status'] = $success ? 'pending' : 'failed';
        $result['message'] = $message;
        $result['error_message'] = $success ? '' : ((string) ($result['error_message'] ?? '') ?: 'Richiesta aggiornamento fallita.');

        return $result;
    }

    public static function requestPluginUpdate(array $site, array $plugin, string $jobId = '', int $step = 1, int $total = 1): array
    {
        return self::requestUpdateItem($site, 'plugin', $plugin, $jobId, $step, $total);
    }

    public static function requestThemeUpdate(array $site, array $theme, string $jobId = '', int $step = 1, int $total = 1): array
    {
        return self::requestUpdateItem($site, 'theme', $theme, $jobId, $step, $total);
    }

    public static function requestUpdateExclusion(array $site, string $type, string $identifier, bool $excluded, array $item = []): array
    {
        $type = self::sanitizeKey($type) === 'theme' ? 'theme' : 'plugin';
        $parameters = [
            'type' => $type,
            'identifier' => self::text($identifier),
            'file' => self::pluginFile((string) ($item['file'] ?? '')),
            'slug' => self::text((string) ($item['slug'] ?? '')),
            'name' => self::text((string) ($item['name'] ?? '')),
            'excluded' => $excluded ? 1 : 0,
        ];

        $result = self::requestOperation($site, 'set_update_exclusion', $parameters, 30);
        $success = !empty($result['success']);
        $result['status'] = $success ? 'ok' : 'failed';
        $result['message'] = $success && trim((string) ($result['message'] ?? '')) !== ''
            ? (string) $result['message']
            : ($excluded ? 'Elemento escluso dagli aggiornamenti.' : 'Elemento riammesso negli aggiornamenti.');
        $result['error_message'] = $success ? '' : ((string) ($result['error_message'] ?? '') ?: 'Cambio esclusione aggiornamenti fallito.');
        if (!$success && (string) ($result['error_type'] ?? '') === 'unsupported_operation') {
            $result['error_message'] = 'Esclusioni remote non supportate dal client MCU: aggiorna il plugin MCU.';
        }

        return $result;
    }

    public static function requestUpdateItem(array $site, string $updateType, array $item, string $jobId = '', int $step = 1, int $total = 1): array
    {
        $updateType = self::sanitizeKey($updateType) === 'theme' ? 'theme' : 'plugin';
        $parameters = [
            'plugin_file' => self::pluginFile((string) ($item['file'] ?? $item['plugin_file'] ?? '')),
            'slug' => self::pluginSlug((string) ($item['slug'] ?? '')),
            'name' => self::text((string) ($item['name'] ?? '')),
            'type' => self::sanitizeKey((string) ($item['type'] ?? '')),
            'current_version' => self::text((string) ($item['current_version'] ?? '')),
            'new_version' => self::text((string) ($item['new_version'] ?? $item['version'] ?? '')),
            'package' => self::url((string) ($item['package'] ?? '')),
            'job_id' => self::text($jobId),
            'step' => max(1, $step),
            'total' => max(1, $total),
        ];

        $result = self::requestOperation($site, $updateType === 'theme' ? 'update_theme' : 'update_plugin', $parameters, 300);
        $success = !empty($result['success']);
        $result['status'] = $success ? 'ok' : 'failed';
        $label = $updateType === 'theme' ? 'tema' : 'plugin';
        $result['message'] = $success && trim((string) ($result['message'] ?? '')) !== ''
            ? (string) $result['message']
            : 'Aggiornamento ' . $label . ' completato.';
        $result['error_message'] = $success ? '' : ((string) ($result['error_message'] ?? '') ?: 'Aggiornamento ' . $label . ' fallito.');
        if (!$success && (string) ($result['error_type'] ?? '') === 'unsupported_operation') {
            $result['error_message'] = 'Aggiornamento ' . $label . ' diretto non supportato dal client MCU: aggiorna il plugin MCU oppure usa il flusso legacy via cron.';
        }

        return $result;
    }

    public static function requestForceSync(array $site): array
    {
        @set_time_limit(180);
        $result = self::requestOperation($site, 'force_sync', [], 120);
        $success = !empty($result['success']);
        $result['status'] = $success ? 'ok' : 'failed';
        $result['message'] = $success && trim((string) ($result['message'] ?? '')) !== ''
            ? (string) $result['message']
            : 'Sincronizzazione MCU completata.';
        $result['error_message'] = $success ? '' : ((string) ($result['error_message'] ?? '') ?: 'Sincronizzazione MCU fallita.');

        return $result;
    }

    public static function requestCancelMasterUpdate(array $site): array
    {
        $result = self::requestOperation($site, 'cancel_master_update');
        $success = !empty($result['success']);
        $result['status'] = $success ? 'ok' : 'failed';
        $result['message'] = $success && trim((string) ($result['message'] ?? '')) !== ''
            ? (string) $result['message']
            : 'Richiesta cron Master/Commander annullata.';
        $result['error_message'] = $success ? '' : ((string) ($result['error_message'] ?? '') ?: 'Annullamento cron Master/Commander fallito.');

        return $result;
    }

    public static function requestDebugToggle(array $site, bool $enabled): array
    {
        $result = self::requestOperation($site, 'debug_toggle', ['enabled' => $enabled ? 1 : 0], 30);
        $success = !empty($result['success']);
        $result['status'] = $success ? 'ok' : 'failed';
        $result['message'] = $success && trim((string) ($result['message'] ?? '')) !== ''
            ? (string) $result['message']
            : ($enabled ? 'Debug WordPress attivato.' : 'Debug WordPress disattivato.');
        $result['error_message'] = $success ? '' : ((string) ($result['error_message'] ?? '') ?: 'Cambio stato debug fallito.');
        if (!$success && (string) ($result['error_type'] ?? '') === 'unsupported_operation') {
            $result['error_message'] = 'Debug remoto non supportato dal client MCU: aggiorna il plugin MCU.';
        }

        return $result;
    }

    public static function requestDebugLogDelete(array $site): array
    {
        $result = self::requestOperation($site, 'debug_log_delete', [], 30);
        $success = !empty($result['success']);
        $result['status'] = $success ? 'ok' : 'failed';
        $result['message'] = $success && trim((string) ($result['message'] ?? '')) !== ''
            ? (string) $result['message']
            : 'debug.log eliminato.';
        $result['error_message'] = $success ? '' : ((string) ($result['error_message'] ?? '') ?: 'Eliminazione debug.log fallita.');
        if (!$success && (string) ($result['error_type'] ?? '') === 'unsupported_operation') {
            $result['error_message'] = 'Eliminazione debug.log non supportata dal client MCU: aggiorna il plugin MCU.';
        }

        return $result;
    }

    public static function requestDebugLogRead(array $site, string $purpose = 'view', int $bytes = 0): array
    {
        $start = microtime(true);
        $siteId = (int) ($site['id'] ?? 0);
        $endpoint = self::debugLogEndpoint((string) ($site['endpoint_url'] ?? ''));
        $timeout = self::timeout($site);
        $secret = MaintenanceSecretVault::decrypt((string) ($site['secret_encrypted'] ?? ''));
        $diagnostics = self::baseDiagnostics($endpoint, self::DEBUG_LOG_REST_PATH, $timeout);
        $purpose = self::sanitizeKey($purpose);
        if (!in_array($purpose, ['view', 'download', 'ai'], true)) {
            $purpose = 'view';
        }
        $bytes = max(0, min(2097152, $bytes));
        $diagnostics['operation'] = 'debug_log_read';
        $diagnostics['purpose'] = $purpose;
        $diagnostics['protocol_v'] = 2;

        if ($secret === '') {
            return self::result('failed', 0, self::durationMs($start), 'missing_secret', 'Stored connection key could not be decrypted.', [], $diagnostics);
        }

        $parameters = ['purpose' => $purpose];
        if ($bytes > 0) {
            $parameters['bytes'] = $bytes;
        }

        $timestamp = (string) time();
        $nonce = self::nonce();
        $body = self::json([
            'site_id' => (string) $siteId,
            'master_url' => self::masterUrl(),
            'master_time' => (int) $timestamp,
            'protocol_v' => 2,
            'parameters' => $parameters,
        ]);
        $headers = self::signedHeaders($siteId, $timestamp, $nonce, self::DEBUG_LOG_REST_PATH, $body, $secret);
        $response = self::postJson($endpoint, $headers, $body, $timeout, $diagnostics, $start);

        if (!empty($response['transport_error'])) {
            $errorType = self::classifyTransportError((string) $response['transport_error']);
            return [
                'status' => 'failed',
                'success' => false,
                'http_code' => 0,
                'duration_ms' => (int) $response['duration_ms'],
                'error_type' => $errorType,
                'message' => '',
                'error_message' => (string) $response['transport_error'],
                'response_data' => [],
                'diagnostics' => $response['diagnostics'],
                'content' => '',
            ];
        }

        $decoded = json_decode((string) $response['body'], true);
        $metadata = is_array($decoded) ? $decoded : [];
        unset($metadata['content_base64']);
        $metadataSafe = self::redactSensitiveValue($metadata);
        $success = (int) $response['http_code'] === 200 && is_array($decoded) && !empty($decoded['success']);
        $message = isset($metadataSafe['message']) && trim((string) $metadataSafe['message']) !== ''
            ? self::text((string) $metadataSafe['message'])
            : '';
        $errorType = '';

        if (!$success) {
            $errorType = isset($metadataSafe['error_code'])
                ? self::sanitizeKey((string) $metadataSafe['error_code'])
                : self::classifyHttpResponse((int) $response['http_code'], is_array($metadataSafe) ? $metadataSafe : [], $response['diagnostics'] ?? []);
        }

        $content = '';
        if ($success) {
            $encoded = (string) ($decoded['content_base64'] ?? '');
            $decodedContent = base64_decode($encoded, true);
            if ($decodedContent === false) {
                $success = false;
                $errorType = 'invalid_debug_log_encoding';
                $message = 'Il Client ha restituito un log non decodificabile.';
            } else {
                $content = $decodedContent;
            }
        }

        $diagnostics = $response['diagnostics'];
        $diagnostics['response'] = $metadataSafe;

        return [
            'status' => $success ? 'ok' : 'failed',
            'success' => $success,
            'http_code' => (int) $response['http_code'],
            'duration_ms' => (int) $response['duration_ms'],
            'error_type' => $errorType,
            'message' => $message,
            'error_message' => $success ? '' : ($message !== '' ? $message : self::publicErrorMessage($errorType, (int) $response['http_code'])),
            'response_data' => is_array($metadataSafe) ? $metadataSafe : [],
            'diagnostics' => $diagnostics,
            'content' => $content,
            'filename' => (string) ($metadata['filename'] ?? ('debug-log-' . date('Ymd-His') . '.log')),
            'truncated' => !empty($metadata['truncated']),
            'bytes_read' => (int) ($metadata['bytes_read'] ?? strlen($content)),
            'debug' => is_array($metadata['debug'] ?? null) ? $metadata['debug'] : [],
        ];
    }

    public static function requestRepositoryConfigRevoke(array $site): array
    {
        if (!Settings::isMcuRepositoryConfigManaged()) {
            return [
                'status' => 'ok',
                'success' => true,
                'http_code' => 0,
                'duration_ms' => 0,
                'error_type' => '',
                'message' => 'Nessuna configurazione repository privata gestita da Commander da revocare.',
                'error_message' => '',
                'response_data' => [],
                'diagnostics' => ['repository_revoke_required' => false],
                'repository_revoke_required' => false,
            ];
        }

        $emptyConfig = self::emptyRepositoryConfig();
        $result = self::requestOperation($site, 'force_sync', [], 30, $emptyConfig);

        $success = !empty($result['success']);
        $result['status'] = $success ? 'ok' : 'failed';
        $result['repository_revoke_required'] = true;
        $result['message'] = $success && trim((string) ($result['message'] ?? '')) !== ''
            ? (string) $result['message']
            : 'Configurazione repository privata disattivata sul client MCU.';
        $result['error_message'] = $success ? '' : ((string) ($result['error_message'] ?? '') ?: 'Revoca configurazione repository privata fallita.');
        $result['diagnostics']['repository_revoke_required'] = true;
        $result['diagnostics']['repository_revoke_strategy'] = 'force_sync_empty_repository_config';

        if (!$success && self::actionRouteMissing($result)) {
            return self::requestRepositoryConfigRevokeViaStatus($site, $emptyConfig, $result);
        }

        return $result;
    }

    private static function requestRepositoryConfigRevokeViaStatus(array $site, array $repositoryConfig, array $previousResult): array
    {
        $result = self::check($site, $repositoryConfig);
        $success = (int) ($result['http_code'] ?? 0) === 200
            && in_array((string) ($result['status'] ?? ''), ['ok', 'updates', 'pending'], true);

        $result['success'] = $success;
        $result['status'] = $success ? 'ok' : 'failed';
        $result['repository_revoke_required'] = true;
        $result['repository_revoke_strategy'] = 'status_empty_repository_config';
        $result['message'] = $success
            ? 'Configurazione repository vuota inviata tramite endpoint stato MCU.'
            : '';
        $result['error_message'] = $success
            ? ''
            : ((string) ($result['error_message'] ?? '') ?: 'Revoca configurazione repository privata fallita anche tramite endpoint stato MCU.');
        $result['diagnostics']['repository_revoke_required'] = true;
        $result['diagnostics']['repository_revoke_strategy'] = 'status_empty_repository_config';
        $result['diagnostics']['previous_action_error_type'] = self::sanitizeKey((string) ($previousResult['error_type'] ?? ''));
        $result['diagnostics']['previous_action_http_code'] = (int) ($previousResult['http_code'] ?? 0);

        return $result;
    }

    private static function emptyRepositoryConfig(): array
    {
        return [
            'managed' => true,
            'plugin_url' => '',
            'theme_url' => '',
        ];
    }

    private static function actionRouteMissing(array $result): bool
    {
        if ((int) ($result['http_code'] ?? 0) !== 404) {
            return false;
        }

        $errorType = self::sanitizeKey((string) ($result['error_type'] ?? ''));
        $message = strtolower((string) ($result['error_message'] ?? ''));
        $response = is_array($result['response_data'] ?? null) ? $result['response_data'] : [];
        $responseCode = self::sanitizeKey((string) ($response['code'] ?? ''));

        return $errorType === 'http_404'
            && ($responseCode === 'rest_no_route' || str_contains($message, 'no route'));
    }

    public static function requestDiagnosticSnapshot(array $site): array
    {
        $result = self::requestOperation($site, 'diagnostics_schedule_snapshot');
        $success = !empty($result['success']);
        $result['status'] = $success ? 'pending' : 'failed';
        $result['message'] = $success && trim((string) ($result['message'] ?? '')) !== ''
            ? (string) $result['message']
            : 'Snapshot diagnostico accodato.';
        $result['error_message'] = $success ? '' : ((string) ($result['error_message'] ?? '') ?: 'Avvio snapshot diagnostico fallito.');
        if (!$success && (string) ($result['error_type'] ?? '') === 'unsupported_operation') {
            $result['error_message'] = 'Avvio manuale snapshot non supportato dal client MCU: aggiorna il plugin MCU.';
        }

        if ($success) {
            $payload = is_array($result['response_data']['data'] ?? null) ? $result['response_data']['data'] : [];
            $snapshot = is_array($payload['snapshot'] ?? null) ? $payload['snapshot'] : [];
            if (!empty($snapshot['available']) && !empty($snapshot['snapshot_id'])) {
                $status = [
                    'diagnostic_schema_version' => (int) ($result['response_data']['schema_version'] ?? 1),
                    'snapshot' => $snapshot,
                ];
                try {
                    MaintenanceSnapshotSyncService::syncManifestFromStatus($site, $status);
                } catch (\Throwable $e) {
                    $result['diagnostics']['snapshot_sync_error'] = self::text($e->getMessage());
                }
            }
        }

        return $result;
    }

    public static function requestDashboardAccess(array $site): array
    {
        $start = microtime(true);
        $siteId = (int) ($site['id'] ?? 0);
        $endpoint = self::dashboardAccessEndpoint($site);
        $timeout = self::timeout($site);
        $secret = MaintenanceSecretVault::decrypt((string) ($site['dashboard_access_key_encrypted'] ?? ''));
        $diagnostics = self::baseDiagnostics($endpoint, self::DASHBOARD_ACCESS_REST_PATH, $timeout);

        if (empty($site['dashboard_access_enabled']) || $endpoint === '' || $secret === '') {
            return self::result('failed', 0, self::durationMs($start), 'dashboard_access_not_configured', 'Dashboard access is not configured for this site.', [], $diagnostics);
        }

        $timestamp = (string) time();
        $nonce = self::nonce();
        $body = self::json([
            'site_id' => (string) $siteId,
            'master_url' => self::masterUrl(),
            'master_time' => (int) $timestamp,
            'protocol_v' => 1,
            'target' => 'wp-admin',
        ]);
        $headers = self::signedHeaders($siteId, $timestamp, $nonce, self::DASHBOARD_ACCESS_REST_PATH, $body, $secret);
        $response = self::postJson($endpoint, $headers, $body, $timeout, $diagnostics, $start);

        if (!empty($response['transport_error'])) {
            return self::result('failed', 0, (int) $response['duration_ms'], 'http_request_failed', (string) $response['transport_error'], [], $response['diagnostics']);
        }

        $decoded = json_decode((string) $response['body'], true);
        $loginUrl = is_array($decoded) && !empty($decoded['login_url']) ? trim((string) $decoded['login_url']) : '';
        $success = (int) $response['http_code'] === 200 && is_array($decoded) && !empty($decoded['success']) && $loginUrl !== '';

        if ($success) {
            return [
                'status' => 'ok',
                'http_code' => (int) $response['http_code'],
                'duration_ms' => (int) $response['duration_ms'],
                'error_type' => '',
                'error_message' => '',
                'login_url' => $loginUrl,
                'expires_in' => isset($decoded['expires_in']) ? max(0, (int) $decoded['expires_in']) : 0,
                'response_data' => [],
                'diagnostics' => ['called_url' => $endpoint],
            ];
        }

        $message = is_array($decoded) && !empty($decoded['message'])
            ? self::text((string) $decoded['message'])
            : 'Richiesta accesso dashboard fallita.';

        return self::result(
            'failed',
            (int) $response['http_code'],
            (int) $response['duration_ms'],
            'dashboard_access_failed',
            $message,
            is_array($decoded) ? self::redactSensitiveValue($decoded) : [],
            $response['diagnostics']
        );
    }

    public static function canonicalString(string $method, string $restPath, string $timestamp, string $nonce, string $body): string
    {
        return strtoupper($method) . "\n" . $restPath . "\n" . $timestamp . "\n" . $nonce . "\n" . $body;
    }

    public static function dashboardAccessEndpoint(array $site): string
    {
        $endpoint = trim((string) ($site['dashboard_access_url'] ?? ''));
        if ($endpoint !== '') {
            return $endpoint;
        }

        $statusEndpoint = (string) ($site['endpoint_url'] ?? '');
        $derived = preg_replace('#/status/?$#', '/dashboard-access', $statusEndpoint);
        return is_string($derived) ? $derived : '';
    }

    private static function actionEndpoint(string $endpoint): string
    {
        $actionEndpoint = preg_replace('#/status/?$#', '/action', $endpoint);
        if (is_string($actionEndpoint) && $actionEndpoint !== '' && $actionEndpoint !== $endpoint) {
            return $actionEndpoint;
        }

        return rtrim($endpoint, '/') . '/action';
    }

    private static function debugLogEndpoint(string $endpoint): string
    {
        $debugEndpoint = preg_replace('#/status/?$#', '/debug-log', $endpoint);
        if (is_string($debugEndpoint) && $debugEndpoint !== '' && $debugEndpoint !== $endpoint) {
            return $debugEndpoint;
        }

        return rtrim($endpoint, '/') . '/debug-log';
    }

    private static function signedHeaders(int $siteId, string $timestamp, string $nonce, string $restPath, string $body, string $secret): array
    {
        $signature = hash_hmac('sha256', self::canonicalString('POST', $restPath, $timestamp, $nonce, $body), $secret);

        return [
            'Accept' => 'application/json',
            'Content-Type' => 'application/json; charset=utf-8',
            'User-Agent' => 'MarrisonCommander/' . self::VERSION . '; ' . self::masterUrl(),
            'X-Marrison-Site-ID' => (string) $siteId,
            'X-Marrison-Timestamp' => $timestamp,
            'X-Marrison-Nonce' => $nonce,
            'X-Marrison-Signature' => 'sha256=' . $signature,
            'X-Marrison-Signature-Version' => 'v1',
        ];
    }

    private static function postJson(string $url, array $headers, string $body, int $timeout, array $diagnostics, float $start): array
    {
        if (function_exists('curl_init')) {
            return self::postJsonWithCurl($url, $headers, $body, $timeout, $diagnostics, $start);
        }

        return self::postJsonWithStream($url, $headers, $body, $timeout, $diagnostics, $start);
    }

    private static function postJsonWithCurl(string $url, array $headers, string $body, int $timeout, array $diagnostics, float $start): array
    {
        $curl = curl_init($url);
        if ($curl === false) {
            $diagnostics['duration_ms'] = self::durationMs($start);
            $diagnostics['curl_error'] = 'Could not initialize cURL.';
            MaintenanceDebugLogger::log('http_request', [
                'url' => $url,
                'http_code' => 0,
                'duration_ms' => $diagnostics['duration_ms'],
                'response_size' => 0,
                'error' => $diagnostics['curl_error'],
            ]);

            return [
                'http_code' => 0,
                'body' => '',
                'duration_ms' => $diagnostics['duration_ms'],
                'diagnostics' => $diagnostics,
                'transport_error' => $diagnostics['curl_error'],
            ];
        }

        $headerLines = [];
        foreach ($headers as $name => $value) {
            $headerLines[] = $name . ': ' . $value;
        }

        curl_setopt_array($curl, [
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER => true,
            CURLOPT_HTTPHEADER => $headerLines,
            CURLOPT_POSTFIELDS => $body,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_CONNECTTIMEOUT => min(10, $timeout),
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_MAXREDIRS => 0,
        ]);

        $raw = curl_exec($curl);
        $error = $raw === false ? curl_error($curl) : '';
        $httpCode = (int) curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
        $headerSize = (int) curl_getinfo($curl, CURLINFO_HEADER_SIZE);
        $finalUrl = (string) curl_getinfo($curl, CURLINFO_EFFECTIVE_URL);
        $redirectCount = (int) curl_getinfo($curl, CURLINFO_REDIRECT_COUNT);
        curl_close($curl);

        $raw = is_string($raw) ? $raw : '';
        $headerRaw = $headerSize > 0 ? substr($raw, 0, $headerSize) : '';
        $responseBody = $headerSize > 0 ? substr($raw, $headerSize) : $raw;

        $diagnostics['http_code'] = $httpCode;
        $diagnostics['duration_ms'] = self::durationMs($start);
        $diagnostics['response_size'] = strlen($responseBody);
        $diagnostics['final_url'] = $finalUrl;
        $diagnostics['redirect_count'] = $redirectCount;
        $diagnostics['response_headers'] = self::safeHeadersFromRaw($headerRaw);
        $diagnostics['response_body_preview'] = self::bodyPreview($responseBody);
        $diagnostics['curl_error'] = $error !== '' ? $error : null;
        $diagnostics['master_nonce'] = '<redacted>';

        MaintenanceDebugLogger::log('http_request', [
            'url' => $url,
            'http_code' => $httpCode,
            'duration_ms' => $diagnostics['duration_ms'],
            'response_size' => $diagnostics['response_size'],
            'error' => $error,
        ]);

        return [
            'http_code' => $httpCode,
            'body' => $responseBody,
            'duration_ms' => $diagnostics['duration_ms'],
            'diagnostics' => $diagnostics,
            'transport_error' => $error,
        ];
    }

    private static function postJsonWithStream(string $url, array $headers, string $body, int $timeout, array $diagnostics, float $start): array
    {
        $headerLines = [];
        foreach ($headers as $name => $value) {
            $headerLines[] = $name . ': ' . $value;
        }

        $context = stream_context_create([
            'http' => [
                'method' => 'POST',
                'header' => implode("\r\n", $headerLines),
                'content' => $body,
                'timeout' => $timeout,
                'ignore_errors' => true,
                'follow_location' => 0,
                'max_redirects' => 0,
            ],
            'ssl' => [
                'verify_peer' => true,
                'verify_peer_name' => true,
            ],
        ]);

        $handle = @fopen($url, 'r', false, $context);
        if ($handle === false) {
            $responseBody = '';
            $error = error_get_last()['message'] ?? 'HTTP request failed';
            $rawHeaders = '';
        } else {
            $responseBody = stream_get_contents($handle);
            $meta = stream_get_meta_data($handle);
            fclose($handle);
            $error = $responseBody === false ? (error_get_last()['message'] ?? 'HTTP request failed') : '';
            $responseBody = is_string($responseBody) ? $responseBody : '';
            $headersArray = isset($meta['wrapper_data']) && is_array($meta['wrapper_data']) ? $meta['wrapper_data'] : [];
            $rawHeaders = implode("\r\n", $headersArray);
        }
        $httpCode = self::httpCodeFromRawHeaders($rawHeaders);

        $diagnostics['http_code'] = $httpCode;
        $diagnostics['duration_ms'] = self::durationMs($start);
        $diagnostics['response_size'] = strlen($responseBody);
        $diagnostics['final_url'] = $url;
        $diagnostics['redirect_count'] = 0;
        $diagnostics['response_headers'] = self::safeHeadersFromRaw($rawHeaders);
        $diagnostics['response_body_preview'] = self::bodyPreview($responseBody);
        $diagnostics['curl_error'] = null;
        $diagnostics['stream_error'] = $error !== '' ? $error : null;
        $diagnostics['master_nonce'] = '<redacted>';

        MaintenanceDebugLogger::log('http_request', [
            'url' => $url,
            'http_code' => $httpCode,
            'duration_ms' => $diagnostics['duration_ms'],
            'response_size' => $diagnostics['response_size'],
            'error' => $error,
        ]);

        return [
            'http_code' => $httpCode,
            'body' => $responseBody,
            'duration_ms' => $diagnostics['duration_ms'],
            'diagnostics' => $diagnostics,
            'transport_error' => $error,
        ];
    }

    private static function baseDiagnostics(string $url, string $canonicalRestPath, int $timeout): array
    {
        return [
            'called_url' => $url,
            'method' => 'POST',
            'canonical_rest_path' => $canonicalRestPath,
            'timeout_seconds' => $timeout,
            'sslverify' => true,
            'http_code' => 0,
            'duration_ms' => 0,
            'response_size' => 0,
            'redirect_count' => 0,
            'wordpress_error' => null,
            'curl_error' => null,
            'stream_error' => null,
            'response_json' => null,
            'response_body_preview' => '',
            'time_skew_seconds' => null,
            'authentication_protocol' => [
                'hmac' => 'sha256',
                'signature_header' => 'sha256=<redacted>',
                'timestamp_window' => 300,
                'nonce' => 'one-time random value',
            ],
        ];
    }

    private static function result(string $status, int $httpCode, int $durationMs, string $errorType, string $errorMessage, array $responseData, array $diagnostics): array
    {
        return [
            'status' => self::sanitizeKey($status),
            'http_code' => $httpCode,
            'duration_ms' => $durationMs,
            'error_type' => self::sanitizeKey($errorType),
            'error_message' => self::text($errorMessage),
            'response_data' => $responseData,
            'diagnostics' => $diagnostics,
        ];
    }

    private static function updatesCount(array $response): int
    {
        if (self::hasUpdateDetails($response)) {
            return self::pluginUpdatesCount($response)
                + self::listedOrCountedUpdates($response, ['theme_updates', 'theme_update_items'], 'theme_updates_count')
                + self::listedOrCountedUpdates($response, ['translation_updates', 'translation_update_items'], 'translation_updates_count');
        }

        if (array_key_exists('updates_available_count', $response)) {
            return max(0, (int) $response['updates_available_count']);
        }

        return self::pluginUpdatesCount($response)
            + self::listedOrCountedUpdates($response, ['theme_updates', 'theme_update_items'], 'theme_updates_count')
            + self::listedOrCountedUpdates($response, ['translation_updates', 'translation_update_items'], 'translation_updates_count');
    }

    private static function hasUpdateDetails(array $response): bool
    {
        foreach (['plugin_updates', 'theme_updates', 'theme_update_items', 'translation_updates', 'translation_update_items'] as $key) {
            if (isset($response[$key]) && is_array($response[$key])) {
                return true;
            }
        }

        foreach (['plugin_updates_count', 'theme_updates_count', 'translation_updates_count'] as $key) {
            if (array_key_exists($key, $response) && is_numeric($response[$key])) {
                return true;
            }
        }

        return false;
    }

    private static function pluginUpdatesCount(array $response): int
    {
        $pluginCount = 0;
        if (isset($response['plugin_updates']) && is_array($response['plugin_updates'])) {
            $seen = [];
            foreach ($response['plugin_updates'] as $update) {
                if (!is_array($update)) {
                    continue;
                }
                $key = strtolower(trim((string) ($update['file'] ?? $update['name'] ?? '')));
                if ($key !== '' && !isset($seen[$key])) {
                    $seen[$key] = true;
                    $pluginCount++;
                }
            }
        } elseif (isset($response['plugin_updates_count'])) {
            $pluginCount = max(0, (int) $response['plugin_updates_count']);
        }

        return $pluginCount;
    }

    private static function listedOrCountedUpdates(array $response, array $listKeys, string $countKey): int
    {
        foreach ($listKeys as $listKey) {
            if (isset($response[$listKey]) && is_array($response[$listKey])) {
                return count($response[$listKey]);
            }
        }

        return isset($response[$countKey]) ? max(0, (int) $response[$countKey]) : 0;
    }

    private static function classifyTransportError(string $message): string
    {
        $lower = strtolower($message);
        if (str_contains($lower, 'timed out') || str_contains($lower, 'operation timed out') || str_contains($lower, 'curl error 28')) {
            return 'timeout';
        }
        if (str_contains($lower, 'could not resolve host') || str_contains($lower, 'getaddrinfo') || str_contains($lower, 'dns')) {
            return 'dns_error';
        }
        if (str_contains($lower, 'ssl') || str_contains($lower, 'certificate') || str_contains($lower, 'curl error 60') || str_contains($lower, 'curl error 77') || str_contains($lower, 'curl error 35')) {
            return 'ssl_error';
        }

        return 'http_request_failed';
    }

    private static function classifyHttpResponse(int $httpCode, array $decoded, array $diagnostics = []): string
    {
        $responseCode = self::sanitizeKey((string) ($decoded['code'] ?? ''));
        if ($responseCode === 'marrison_signature_rejected') {
            return 'signature_rejected';
        }
        if ($responseCode === 'marrison_timestamp_expired') {
            return 'timestamp_expired';
        }
        if ($responseCode === 'marrison_nonce_reused') {
            return 'nonce_reused';
        }
        if ($responseCode === 'marrison_auth_failed') {
            return 'authentication_failed';
        }
        if ($httpCode === 403 && self::isCloudflareChallenge($diagnostics)) {
            return 'cloudflare_challenge';
        }
        if ($httpCode === 401) {
            return 'http_401';
        }
        if ($httpCode === 403) {
            return 'http_403';
        }
        if ($httpCode === 404) {
            return 'http_404';
        }
        if ($httpCode === 429) {
            return 'http_429';
        }
        if ($httpCode >= 500) {
            return 'http_500';
        }

        return 'unexpected_response';
    }

    private static function publicErrorMessage(string $errorType, int $httpCode): string
    {
        $messages = [
            'dns_error' => 'DNS lookup failed.',
            'timeout' => 'The Client did not respond before timeout.',
            'ssl_error' => 'SSL verification failed.',
            'http_401' => 'HTTP 401 unauthorized.',
            'http_403' => 'HTTP 403 forbidden.',
            'http_404' => 'HTTP 404 not found.',
            'http_429' => 'HTTP 429 rate limited.',
            'http_500' => 'HTTP server error.',
            'cloudflare_challenge' => 'Cloudflare blocked the Client request with a challenge. Create a Skip/Allow rule for the MCU REST endpoint from the Commander IP.',
            'invalid_json' => 'Invalid JSON response.',
            'signature_rejected' => 'The Client rejected the signature.',
            'timestamp_expired' => 'The Client rejected the timestamp.',
            'nonce_reused' => 'The Client rejected a reused nonce.',
            'authentication_failed' => 'Authentication failed.',
            'missing_secret' => 'Stored connection key could not be decrypted.',
        ];

        if (isset($messages[$errorType])) {
            return $messages[$errorType];
        }

        return $httpCode > 0 ? 'Unexpected HTTP response: ' . $httpCode . '.' : 'Unexpected request failure.';
    }

    private static function isCloudflareChallenge(array $diagnostics): bool
    {
        $headers = isset($diagnostics['response_headers']) && is_array($diagnostics['response_headers'])
            ? $diagnostics['response_headers']
            : [];
        $server = strtolower((string) ($headers['server'] ?? ''));
        $cfMitigated = strtolower((string) ($headers['cf-mitigated'] ?? $headers['cf_mitigated'] ?? ''));

        if ($cfMitigated === 'challenge') {
            return true;
        }
        if ($server === 'cloudflare' && (isset($headers['cf-ray']) || isset($headers['cf_ray']))) {
            return true;
        }

        $preview = strtolower((string) ($diagnostics['response_body_preview'] ?? ''));
        return str_contains($preview, 'cloudflare') && str_contains($preview, 'just a moment');
    }

    private static function safeHeadersFromRaw(string $raw): array
    {
        $blocks = preg_split("/\r\n\r\n|\n\n|\r\r/", trim($raw));
        $last = $blocks ? (string) end($blocks) : '';
        $safe = [];

        foreach (preg_split("/\r\n|\n|\r/", $last) ?: [] as $line) {
            if (!str_contains($line, ':')) {
                continue;
            }
            [$name, $value] = array_map('trim', explode(':', $line, 2));
            $lower = strtolower($name);
            if (in_array($lower, ['set-cookie', 'cookie', 'authorization'], true)) {
                continue;
            }
            $safe[self::sanitizeKey($name)] = self::text($value);
        }

        return $safe;
    }

    private static function httpCodeFromRawHeaders(string $raw): int
    {
        if (preg_match_all('/^HTTP\/\S+\s+(\d{3})/mi', $raw, $matches) && !empty($matches[1])) {
            return (int) end($matches[1]);
        }

        return 0;
    }

    private static function redactSensitiveValue($value)
    {
        if (is_array($value)) {
            $redacted = [];
            foreach ($value as $key => $item) {
                if (self::isSensitiveKey((string) $key)) {
                    $redacted[$key] = '<redacted>';
                    continue;
                }
                $redacted[$key] = self::redactSensitiveValue($item);
            }
            return $redacted;
        }

        if (is_string($value)) {
            return self::redactSensitiveText($value);
        }

        return $value;
    }

    private static function bodyPreview(string $body): string
    {
        return substr(self::redactSensitiveText(strip_tags($body)), 0, 4096);
    }

    private static function redactSensitiveText(string $text): string
    {
        $text = preg_replace('/sha256=[a-f0-9]{64}/i', 'sha256=<redacted>', $text);
        $text = preg_replace('/(x-marrison-signature\s*[:=]\s*)([^\s,"\']+)/i', '$1<redacted>', (string) $text);
        $text = preg_replace('/(authorization\s*[:=]\s*)([^\s,"\']+)/i', '$1<redacted>', (string) $text);
        $text = preg_replace('/(cookie\s*[:=]\s*)([^\r\n]+)/i', '$1<redacted>', (string) $text);

        return is_string($text) ? $text : '';
    }

    private static function isSensitiveKey(string $key): bool
    {
        $lower = strtolower($key);
        foreach (['secret', 'key', 'signature', 'token', 'password', 'cookie', 'authorization'] as $needle) {
            if (str_contains($lower, $needle)) {
                return true;
            }
        }

        return false;
    }

    private static function timeout(array $site): int
    {
        return max(3, min(60, (int) ($site['timeout_seconds'] ?? 15)));
    }

    private static function pluginFile(string $file): string
    {
        $file = str_replace('\\', '/', trim($file));
        $file = ltrim($file, '/');
        if ($file === '' || !str_ends_with($file, '.php')) {
            return '';
        }
        if (str_contains($file, '..') || !preg_match('#^[A-Za-z0-9._/-]+$#', $file)) {
            return '';
        }

        return $file;
    }

    private static function pluginSlug(string $slug): string
    {
        $slug = preg_replace('/[^A-Za-z0-9._-]/', '', trim($slug));
        return substr((string) $slug, 0, 180);
    }

    private static function url(string $url): string
    {
        $url = trim($url);
        if ($url === '') {
            return '';
        }

        return filter_var($url, FILTER_VALIDATE_URL) ? $url : '';
    }

    private static function nonce(): string
    {
        try {
            return bin2hex(random_bytes(16));
        } catch (\Throwable $e) {
            return bin2hex((string) uniqid('', true));
        }
    }

    private static function json(array $data): string
    {
        $json = json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        return is_string($json) ? $json : '{}';
    }

    private static function safeOperationParameters(array $parameters): array
    {
        unset($parameters['force'], $parameters['bypass_rate_limit'], $parameters['operation']);
        return MaintenanceDiagnosticSanitizer::sanitize($parameters);
    }

    private static function durationMs(float $start): int
    {
        return (int) round((microtime(true) - $start) * 1000);
    }

    private static function masterUrl(): string
    {
        $configured = rtrim((string) config('app.base_url', ''), '/');
        if ($configured !== '') {
            return $configured;
        }

        $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $host = (string) ($_SERVER['HTTP_HOST'] ?? '');
        return $host !== '' ? $scheme . '://' . $host : 'marrison-commander';
    }

    private static function jobCallbackUrl(): string
    {
        $base = rtrim((string) config('app.base_url', ''), '/');
        if ($base === '' || !filter_var($base, FILTER_VALIDATE_URL)) {
            return '';
        }

        $scheme = strtolower((string) parse_url($base, PHP_URL_SCHEME));
        if (!in_array($scheme, ['http', 'https'], true)) {
            return '';
        }

        return \base_url('/wp-json' . self::COMMANDER_JOB_CALLBACK_PATH);
    }

    private static function sanitizeKey(string $value): string
    {
        return preg_replace('/[^a-z0-9_\-]/', '', strtolower($value)) ?: '';
    }

    private static function text(string $value): string
    {
        $value = strip_tags($value);
        $value = preg_replace('/[\r\n\t]+/', ' ', $value);
        $value = preg_replace('/\s+/', ' ', (string) $value);
        return trim((string) $value);
    }
}
