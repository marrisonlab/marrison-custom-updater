<?php

namespace App\Services;

use App\Models\MaintenanceMonitorState;
use App\Models\MaintenanceSignal;
use App\Models\MaintenanceSite;

/**
 * Commander-side proactive monitoring runner.
 */
class MaintenanceMonitorService
{
    private const HEARTBEAT_INTERVAL = 900;
    private const STATUS_INTERVAL = 3600;
    private const SNAPSHOT_INTERVAL = 86400;
    private const FRONTEND_INTERVAL = 86400;
    private const AI_INTERVAL = 21600;

    public static function tick(int $limit = 10, array $options = []): array
    {
        $limit = max(1, min(100, $limit));
        $enableFrontend = !empty($options['frontend']);
        $enableAi = !empty($options['ai']);
        $budget = $limit;
        $verification = MaintenanceVerificationSchedule::configuration();
        $summary = [
            'success' => true,
            'limit' => $limit,
            'processed' => 0,
            'heartbeat' => 0,
            'status' => 0,
            'updates' => 0,
            'snapshot' => 0,
            'frontend' => 0,
            'ai' => 0,
            'failed' => 0,
            'sites' => [],
        ];

        self::ensureStates();

        $dueFields = [
            'heartbeat' => 'heartbeat_due_at',
            'status' => 'status_due_at',
            'updates' => 'updates_due_at',
            'snapshot' => 'snapshot_due_at',
            'frontend' => 'frontend_due_at',
        ];
        $dueLists = [];
        $positions = [];

        foreach ($dueFields as $kind => $dueField) {
            if ($kind === 'updates' && !$verification['enabled']) {
                continue;
            }
            if ($kind === 'frontend' && !$enableFrontend) {
                continue;
            }
            $dueLists[$kind] = MaintenanceMonitorState::dueSiteIds($dueField, $limit);
            $positions[$kind] = 0;
        }

        while ($budget > 0) {
            $processedRound = false;
            foreach ($dueFields as $kind => $dueField) {
                if ($budget <= 0) {
                    break;
                }
                if (!isset($dueLists[$kind])) {
                    continue;
                }

                $position = $positions[$kind] ?? 0;
                if (!isset($dueLists[$kind][$position])) {
                    continue;
                }

                $siteId = (int) $dueLists[$kind][$position];
                $positions[$kind] = $position + 1;
                try {
                    $result = self::runKind($siteId, $kind, $options + ['ai' => $enableAi]);
                } catch (\Throwable $e) {
                    $result = [
                        'site_id' => $siteId,
                        'kind' => $kind,
                        'success' => false,
                        'error' => preg_replace('/[\r\n]+/', ' ', $e->getMessage()),
                    ];
                }
                $summary[$kind]++;
                if (isset($result['ai'])) {
                    $summary['ai']++;
                }
                if (empty($result['success'])) {
                    $summary['failed']++;
                }
                $summary['processed']++;
                $summary['sites'][] = $result;
                $budget--;
                $processedRound = true;
            }

            if (!$processedRound) {
                break;
            }
        }

        $summary['success'] = $summary['failed'] === 0;
        return $summary;
    }

    public static function runSite(int $siteId, array $options = []): array
    {
        $kinds = isset($options['kinds']) && is_array($options['kinds'])
            ? array_values(array_filter(array_map('strval', $options['kinds'])))
            : ['heartbeat', 'status', 'signals'];

        $results = [];
        foreach ($kinds as $kind) {
            $results[] = self::runKind($siteId, $kind, $options);
        }

        return [
            'success' => true,
            'site_id' => $siteId,
            'results' => $results,
            'signals' => MaintenanceSignal::activeForSite($siteId),
        ];
    }

    private static function runKind(int $siteId, string $kind, array $options): array
    {
        $site = MaintenanceSite::find($siteId);
        if (!$site) {
            return ['site_id' => $siteId, 'kind' => $kind, 'success' => false, 'error' => 'site_not_found'];
        }

        $kind = self::kind($kind);
        $result = ['site_id' => $siteId, 'kind' => $kind, 'success' => true];

        if ($kind === 'heartbeat') {
            $result['home'] = MaintenanceExternalProbeService::probe($site, 'home', '', 0);
            $result['wp_json'] = MaintenanceExternalProbeService::probe($site, 'wp_json', '', 0);
            MaintenanceMonitorState::mark($siteId, 'heartbeat', self::HEARTBEAT_INTERVAL);
            $result['signals'] = MaintenanceSignalService::analyzeSite($siteId)['signals'] ?? [];
            return $result;
        }

        if ($kind === 'status') {
            $check = MaintenanceHttpClient::check($site);
            MaintenanceSite::storeCheckResult($siteId, $check);
            MaintenanceMonitorState::mark($siteId, 'status', self::STATUS_INTERVAL);
            $result['check'] = $check;
            $result['signals'] = MaintenanceSignalService::analyzeSite($siteId)['signals'] ?? [];
            self::maybeRunAi($siteId, $options, $result);
            return $result;
        }

        if ($kind === 'updates') {
            $check = MaintenanceHttpClient::verifyUpdates($site);
            MaintenanceSite::storeActionResult($siteId, $check, 'force_sync');
            MaintenanceSite::storeCheckResult($siteId, $check);
            $result['success'] = ($check['status'] ?? 'failed') !== 'failed';
            MaintenanceMonitorState::markUpdates($siteId, $result['success']);
            $result['check'] = $check;
            $result['signals'] = MaintenanceSignalService::analyzeSite($siteId)['signals'] ?? [];
            self::maybeRunAi($siteId, $options, $result);
            return $result;
        }

        if ($kind === 'snapshot') {
            $sync = MaintenanceDiagnosticService::syncAvailableSnapshot($siteId);
            MaintenanceMonitorState::mark($siteId, 'snapshot', self::SNAPSHOT_INTERVAL);
            $result['snapshot_sync'] = $sync;
            $result['signals'] = MaintenanceSignalService::analyzeSite($siteId)['signals'] ?? [];
            return $result;
        }

        if ($kind === 'frontend') {
            $active = MaintenanceSignal::activeForSite($siteId);
            if (empty($options['force_frontend']) && !self::hasSeriousSignal($active)) {
                MaintenanceMonitorState::mark($siteId, 'frontend', self::FRONTEND_INTERVAL);
                $result['skipped'] = 'no_serious_signal';
                return $result;
            }
            $scan = MaintenanceFrontendScannerService::scan($site, (int) ($options['max_urls'] ?? 12));
            MaintenanceMonitorState::mark($siteId, 'frontend', self::FRONTEND_INTERVAL);
            $result['scan'] = $scan;
            $result['signals'] = MaintenanceSignalService::analyzeSite($siteId)['signals'] ?? [];
            self::maybeRunAi($siteId, $options, $result);
            return $result;
        }

        if ($kind === 'signals') {
            $result['signals'] = MaintenanceSignalService::analyzeSite($siteId)['signals'] ?? [];
            return $result;
        }

        return ['site_id' => $siteId, 'kind' => $kind, 'success' => false, 'error' => 'unsupported_kind'];
    }

    private static function maybeRunAi(int $siteId, array $options, array &$result): void
    {
        if (empty($options['ai'])) {
            return;
        }

        $signals = MaintenanceSignal::activeForSite($siteId);
        if (!self::hasSeriousSignal($signals) && empty($options['force_ai'])) {
            return;
        }
        if (empty($options['force_ai']) && !self::aiIsDue($siteId)) {
            return;
        }

        $result['ai'] = MaintenanceAiAnalysisService::analyzeSite($siteId);
        MaintenanceMonitorState::markAiRun($siteId);
    }

    private static function aiIsDue(int $siteId): bool
    {
        $state = MaintenanceMonitorState::find($siteId);
        $last = $state ? strtotime((string) ($state['last_ai_at'] ?? '')) : false;
        return !$last || (time() - (int) $last) >= self::AI_INTERVAL;
    }

    private static function hasSeriousSignal(array $signals): bool
    {
        foreach ($signals as $signal) {
            if (in_array((string) ($signal['severity'] ?? ''), ['critical', 'warning'], true)) {
                return true;
            }
        }

        return false;
    }

    private static function ensureStates(): void
    {
        foreach (MaintenanceSite::all() as $site) {
            MaintenanceMonitorState::ensure((int) ($site['id'] ?? 0));
        }
    }

    private static function kind(string $kind): string
    {
        return preg_replace('/[^a-z0-9_]/', '', strtolower($kind)) ?: '';
    }
}
