<?php

namespace App\Controllers;

use App\Models\MaintenanceSite;
use App\Models\MaintenanceUpdateJob;
use App\Services\MaintenanceSecretVault;

/**
 * Receives signed MCU update job callbacks.
 */
class MaintenanceJobCallbackController
{
    public const CANONICAL_REST_PATH = '/marrison-commander/v1/maintenance-job-callback';
    private const TIMESTAMP_TOLERANCE = 300;

    public function handle(): void
    {
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
            json_error('Metodo non consentito', 405);
        }

        $rawBody = (string) file_get_contents('php://input');
        if (strlen($rawBody) > 1048576) {
            json_error('Payload troppo grande', 413);
        }

        $siteId = (int) self::header('X-Marrison-Site-ID');
        $site = MaintenanceSite::find($siteId);
        if (!$site) {
            json_error('Sito non trovato', 404);
        }

        $auth = $this->authenticate($site, $rawBody);
        if (!$auth['ok']) {
            json_error('Firma callback non valida', (int) $auth['status'], ['reason' => $auth['reason']]);
        }

        $payload = json_decode($rawBody, true);
        if (!is_array($payload)) {
            json_error('JSON callback non valido', 400);
        }

        $bodySiteId = (int) ($payload['site_id'] ?? 0);
        if ($bodySiteId > 0 && $bodySiteId !== $siteId) {
            json_error('Sito callback non coerente', 403);
        }

        $job = MaintenanceUpdateJob::recordCallback($siteId, $payload);
        if (!$job) {
            json_error('Job callback non valido', 400);
        }

        $jobStatus = (string) ($job['status'] ?? '');
        if (MaintenanceUpdateJob::isTerminal($jobStatus)) {
            $jobMessage = trim((string) ($job['message'] ?? $job['last_error_message'] ?? ''));
            MaintenanceSite::storeActionResult($siteId, [
                'status' => $jobStatus === 'failed' ? 'failed' : 'pending',
                'http_code' => 200,
                'duration_ms' => 0,
                'error_type' => '',
                'message' => $jobStatus === 'failed' ? $jobMessage : $jobMessage . ' In attesa della verifica finale con sincronizzazione forzata.',
                'error_message' => $jobStatus === 'failed' ? $jobMessage : '',
                'diagnostics' => [
                    'source' => 'mcu_job_callback',
                    'remote_job_id' => (string) ($job['remote_job_id'] ?? ''),
                    'job_status' => $jobStatus,
                ],
            ], 'update_all_callback');
        }

        json_response([
            'success' => true,
            'job' => MaintenanceUpdateJob::publicPayload($job),
        ]);
    }

    private function authenticate(array $site, string $rawBody): array
    {
        $timestamp = self::header('X-Marrison-Timestamp');
        $nonce = self::header('X-Marrison-Nonce');
        $signature = self::header('X-Marrison-Signature');

        if ($timestamp === '' || $nonce === '' || $signature === '') {
            return self::authFail(401, 'missing_headers');
        }
        if (!ctype_digit($timestamp)) {
            return self::authFail(401, 'invalid_timestamp');
        }
        if (abs(time() - (int) $timestamp) > self::TIMESTAMP_TOLERANCE) {
            return self::authFail(401, 'timestamp_expired');
        }
        if (!preg_match('/^[A-Za-z0-9._:-]{12,128}$/', $nonce)) {
            return self::authFail(401, 'invalid_nonce');
        }

        $provided = strtolower(trim($signature));
        if (str_starts_with($provided, 'sha256=')) {
            $provided = substr($provided, 7);
        }
        if (!preg_match('/^[a-f0-9]{64}$/', $provided)) {
            return self::authFail(401, 'invalid_signature_format');
        }

        $secret = MaintenanceSecretVault::decrypt((string) ($site['secret_encrypted'] ?? ''));
        if ($secret === '') {
            return self::authFail(401, 'missing_secret');
        }

        $canonical = self::canonicalString('POST', self::CANONICAL_REST_PATH, $timestamp, $nonce, $rawBody);
        $expected = hash_hmac('sha256', $canonical, $secret);
        if (!hash_equals($expected, $provided)) {
            return self::authFail(403, 'signature_rejected');
        }

        if (!MaintenanceUpdateJob::consumeCallbackNonce($nonce)) {
            return self::authFail(401, 'nonce_reused');
        }

        return ['ok' => true, 'status' => 200, 'reason' => 'success'];
    }

    private static function canonicalString(string $method, string $path, string $timestamp, string $nonce, string $body): string
    {
        return strtoupper($method) . "\n" . $path . "\n" . $timestamp . "\n" . $nonce . "\n" . $body;
    }

    private static function header(string $name): string
    {
        $key = 'HTTP_' . strtoupper(str_replace('-', '_', $name));
        return trim((string) ($_SERVER[$key] ?? ''));
    }

    private static function authFail(int $status, string $reason): array
    {
        return ['ok' => false, 'status' => $status, 'reason' => $reason];
    }
}
