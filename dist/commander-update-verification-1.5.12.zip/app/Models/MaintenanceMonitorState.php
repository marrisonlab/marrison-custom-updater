<?php

namespace App\Models;

use PDO;
use App\Services\MaintenanceVerificationSchedule;

/**
 * Commander-side lightweight monitor schedule for maintenance sites.
 */
class MaintenanceMonitorState
{
    private const TABLE = 'maintenance_monitor_state';

    public static function ensure(int $siteId): array
    {
        if ($siteId <= 0) {
            return [];
        }

        $stmt = Database::connection()->prepare(
            'INSERT IGNORE INTO ' . self::TABLE . '
            (maintenance_site_id, heartbeat_due_at, status_due_at, updates_due_at, snapshot_due_at, frontend_due_at, created_at, updated_at)
            VALUES (:site_id, NOW(), NOW(), :updates_due_at, NOW(), NOW(), NOW(), NOW())'
        );
        $stmt->execute(['site_id' => $siteId, 'updates_due_at' => MaintenanceVerificationSchedule::dueAt($siteId)]);

        return self::find($siteId) ?: [];
    }

    public static function find(int $siteId): ?array
    {
        if ($siteId <= 0) {
            return null;
        }

        $stmt = Database::connection()->prepare('SELECT * FROM ' . self::TABLE . ' WHERE maintenance_site_id = :site_id LIMIT 1');
        $stmt->execute(['site_id' => $siteId]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        return is_array($row) ? $row : null;
    }

    public static function dueSiteIds(string $field, int $limit): array
    {
        $field = self::dueField($field);
        if ($field === '') {
            return [];
        }

        $limit = max(1, min(200, $limit));
        $sql = 'SELECT s.id
            FROM maintenance_sites s
            LEFT JOIN ' . self::TABLE . ' m ON m.maintenance_site_id = s.id
            WHERE m.maintenance_site_id IS NULL OR m.' . $field . ' IS NULL OR m.' . $field . ' <= NOW()
            ORDER BY COALESCE(m.' . $field . ', "1970-01-01 00:00:00") ASC, s.id ASC
            LIMIT ' . $limit;

        return array_map('intval', Database::connection()->query($sql)->fetchAll(PDO::FETCH_COLUMN) ?: []);
    }

    public static function mark(int $siteId, string $kind, int $intervalSeconds): void
    {
        if ($siteId <= 0) {
            return;
        }

        self::ensure($siteId);
        $kind = self::kind($kind);
        if ($kind === '') {
            return;
        }

        $jitter = self::jitter($intervalSeconds);
        $next = date('Y-m-d H:i:s', time() + max(60, $intervalSeconds) + $jitter);
        $now = now_str();
        $dueField = $kind . '_due_at';
        $lastField = 'last_' . $kind . '_at';

        $stmt = Database::connection()->prepare(
            'UPDATE ' . self::TABLE . ' SET ' . $dueField . ' = :next_due, ' . $lastField . ' = :last_at, updated_at = NOW()
             WHERE maintenance_site_id = :site_id'
        );
        $stmt->execute([
            'site_id' => $siteId,
            'next_due' => $next,
            'last_at' => $now,
        ]);
    }

    public static function markUpdates(int $siteId, bool $success): void
    {
        self::ensure($siteId);
        $next = $success ? MaintenanceVerificationSchedule::dueAt($siteId, null, true)
            : date('Y-m-d H:i:s', time() + 900);
        Database::connection()->prepare('UPDATE ' . self::TABLE . '
            SET updates_due_at = :next_due, last_updates_at = NOW(), updated_at = NOW()
            WHERE maintenance_site_id = :site_id')->execute(['site_id' => $siteId, 'next_due' => $next]);
    }

    public static function resetUpdateSchedule(): void
    {
        foreach (MaintenanceSite::all() as $site) {
            $siteId = (int) $site['id'];
            self::ensure($siteId);
            Database::connection()->prepare('UPDATE ' . self::TABLE . ' SET updates_due_at = :next_due WHERE maintenance_site_id = :site_id')
                ->execute(['site_id' => $siteId, 'next_due' => MaintenanceVerificationSchedule::dueAt($siteId)]);
        }
    }

    public static function markSignalRun(int $siteId): void
    {
        if ($siteId <= 0) {
            return;
        }

        self::ensure($siteId);
        Database::connection()->prepare(
            'UPDATE ' . self::TABLE . ' SET last_signal_at = NOW(), updated_at = NOW() WHERE maintenance_site_id = :site_id'
        )->execute(['site_id' => $siteId]);
    }

    public static function markAiRun(int $siteId): void
    {
        if ($siteId <= 0) {
            return;
        }

        self::ensure($siteId);
        Database::connection()->prepare(
            'UPDATE ' . self::TABLE . ' SET last_ai_at = NOW(), updated_at = NOW() WHERE maintenance_site_id = :site_id'
        )->execute(['site_id' => $siteId]);
    }

    private static function dueField(string $field): string
    {
        $field = preg_replace('/[^a-z0-9_]/', '', strtolower($field)) ?: '';
        return in_array($field, ['heartbeat_due_at', 'status_due_at', 'updates_due_at', 'snapshot_due_at', 'frontend_due_at'], true)
            ? $field
            : '';
    }

    private static function kind(string $kind): string
    {
        $kind = preg_replace('/[^a-z0-9_]/', '', strtolower($kind)) ?: '';
        return in_array($kind, ['heartbeat', 'status', 'updates', 'snapshot', 'frontend'], true) ? $kind : '';
    }

    private static function jitter(int $intervalSeconds): int
    {
        $window = max(60, min(900, (int) round($intervalSeconds * 0.15)));
        try {
            return random_int(0, $window);
        } catch (\Throwable $e) {
            return mt_rand(0, $window);
        }
    }
}
