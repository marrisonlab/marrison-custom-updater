<?php

require_once dirname(__DIR__, 2) . '/app/bootstrap.php';

use App\Controllers\AdminMaintenanceController;
use App\Models\MaintenanceSignal;
use App\Models\MaintenanceSite;
use App\Models\Settings;
use App\Services\MaintenanceHttpClient;

require_admin_login();

$controller = new AdminMaintenanceController();
$flash = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf($_POST['csrf_token'] ?? null)) {
        $flash = ['type' => 'error', 'message' => 'Token di sicurezza non valido.'];
    } else {
        $action = (string) ($_POST['action'] ?? '');
        if ($action === 'save_maintenance_site') {
            $result = $controller->save($_POST);
            $flash = !empty($result['success'])
                ? ['type' => 'success', 'message' => !empty($result['updated']) ? 'Sito MCU aggiornato.' : 'Sito MCU aggiunto.']
                : ['type' => 'error', 'message' => AdminMaintenanceController::errorMessage((string) ($result['error'] ?? ''))];
        } elseif ($action === 'delete_maintenance_site') {
            $siteId = (int) ($_POST['id'] ?? 0);
            $forceLocalDelete = !empty($_POST['force_local_delete']);
            $site = MaintenanceSite::find($siteId);
            if (!$site) {
                $flash = ['type' => 'error', 'message' => 'Sito MCU non trovato: nessuna rimozione eseguita.'];
            } elseif ($forceLocalDelete) {
                if (!AdminMaintenanceController::localDeleteAvailable($site)) {
                    $flash = ['type' => 'error', 'message' => 'Rimozione locale non disponibile: il sito non presenta un errore di connessione MCU. Ricarica la pagina e usa "Elimina".'];
                } else {
                    MaintenanceSite::delete($siteId);
                    $flash = ['type' => 'success', 'message' => 'Sito MCU rimosso solo da Commander. La revoca remota dei repository non e stata eseguita: l\'eventuale configurazione presente sul sito MCU resta invariata.'];
                }
            } else {
                $revoke = MaintenanceHttpClient::requestRepositoryConfigRevoke($site);
                if (empty($revoke['success'])) {
                    MaintenanceSite::storeActionResult($siteId, $revoke, 'revoke_repository_config');
                    $reason = trim((string) ($revoke['error_message'] ?? ''));
                    $failedSite = MaintenanceSite::find($siteId);
                    $localDeleteHint = $failedSite && AdminMaintenanceController::localDeleteAvailable($failedSite)
                        ? ' Per rimuoverlo senza revoca remota, usa il cestino "Rimuovi solo da Commander" nella riga del sito.'
                        : ' Risolvi l\'errore di revoca e riprova la rimozione.';
                    $flash = ['type' => 'error', 'message' => 'Impossibile revocare l\'accesso ai repository sul sito MCU: il sito non e stato rimosso da Commander.' . ($reason !== '' ? ' Motivo: ' . $reason : '') . $localDeleteHint];
                } else {
                    MaintenanceSite::delete($siteId);
                    $revokeRequired = array_key_exists('repository_revoke_required', $revoke) ? !empty($revoke['repository_revoke_required']) : true;
                    $revokeStrategy = (string) ($revoke['repository_revoke_strategy'] ?? ($revoke['diagnostics']['repository_revoke_strategy'] ?? ''));
                    $flash = [
                        'type' => 'success',
                        'message' => !$revokeRequired
                            ? 'Sito MCU rimosso. Nessuna configurazione repository privata gestita da Commander da revocare.'
                            : ($revokeStrategy === 'status_empty_repository_config'
                                ? 'Sito MCU rimosso. Il client non espone la route action: Commander ha inviato una configurazione repository vuota tramite endpoint stato.'
                                : 'Sito MCU rimosso e accesso ai repository revocato.'),
                    ];
                }
            }
        } elseif ($action === 'import_maintenance_config') {
            $result = $controller->importConfigs($_FILES['maintenance_config'] ?? []);
            if (!empty($result['success'])) {
                $message = 'Configurazioni MCU importate: '
                    . (int) ($result['created'] ?? 0) . ' nuove, '
                    . (int) ($result['updated'] ?? 0) . ' aggiornate';
                if (!empty($result['failed'])) {
                    $message .= ', ' . (int) $result['failed'] . ' non riuscite';
                }
                $message .= '.';
                $flash = ['type' => !empty($result['failed']) ? 'error' : 'success', 'message' => $message];
            } else {
                $flash = ['type' => 'error', 'message' => AdminMaintenanceController::errorMessage((string) ($result['error'] ?? ''))];
            }
        } elseif ($action === 'save_maintenance_debug') {
            Settings::setMaintenanceDebugEnabled(!empty($_POST['maintenance_debug_enabled']));
            $flash = ['type' => 'success', 'message' => 'Impostazioni Maintenance salvate.'];
        }
    }
}

$categories = ['Bilogic', 'HQuadro', 'VOX', 'Marrisonlab'];
$currentCategory = (string) ($_GET['category'] ?? '');
if (!in_array($currentCategory, $categories, true)) {
    $currentCategory = '';
}
$allSites = MaintenanceSite::all();
$pluginCatalog = AdminMaintenanceController::pluginInventoryCatalog($allSites);
$currentPlugin = isset($_GET['plugin']) && is_string($_GET['plugin']) ? trim($_GET['plugin']) : '';
$categorySites = array_values(array_filter($allSites, static function (array $site) use ($currentCategory): bool {
    return $currentCategory === '' || (string) ($site['category'] ?? '') === $currentCategory;
}));
$missingPluginInventories = count(array_filter($categorySites, static function (array $site) use ($pluginCatalog): bool {
    return !isset($pluginCatalog['sites'][(int) $site['id']]);
}));
$sites = array_values(array_filter($categorySites, static function (array $site) use ($currentPlugin, $pluginCatalog): bool {
    return $currentPlugin === '' || isset($pluginCatalog['sites'][(int) $site['id']]['plugins'][$currentPlugin]);
}));
$maintenanceDebugEnabled = Settings::getMaintenanceDebugEnabled();
$currentSort = in_array((string) ($_GET['sort'] ?? ''), ['name', 'client', 'next_update', 'updates'], true)
    ? (string) $_GET['sort']
    : '';
$currentDir = (string) ($_GET['dir'] ?? 'asc') === 'desc' ? 'desc' : 'asc';
$payloads = [];
$stats = [
    'total' => count($sites),
    'updates' => 0,
    'failed' => 0,
    'pending' => 0,
    'signals' => ['critical' => 0, 'warning' => 0, 'info' => 0],
];

foreach ($sites as $site) {
    $payload = AdminMaintenanceController::sitePayload($site);
    $payloads[(int) $site['id']] = $payload;
    $stats['updates'] += max(0, (int) $payload['updatesCount']);
    if (($site['status'] ?? '') === 'failed') {
        $stats['failed']++;
    }
    if (($site['status'] ?? '') === 'pending') {
        $stats['pending']++;
    }
}
$stats['signals'] = MaintenanceSignal::activeCounts();

if ($currentSort !== '') {
    usort($sites, static function (array $a, array $b) use ($payloads, $currentSort, $currentDir): int {
        $aPayload = $payloads[(int) ($a['id'] ?? 0)] ?? [];
        $bPayload = $payloads[(int) ($b['id'] ?? 0)] ?? [];
        $direction = $currentDir === 'desc' ? -1 : 1;

        if ($currentSort === 'name' || $currentSort === 'client') {
            $aValue = $currentSort === 'client'
                ? strtolower((string) ($aPayload['clientVersion'] ?? ''))
                : strtolower((string) ($a['name'] ?? ''));
            $bValue = $currentSort === 'client'
                ? strtolower((string) ($bPayload['clientVersion'] ?? ''))
                : strtolower((string) ($b['name'] ?? ''));
            $result = strnatcasecmp($aValue, $bValue);
            if ($result !== 0) {
                return $result * $direction;
            }
            return ((int) ($a['id'] ?? 0) <=> (int) ($b['id'] ?? 0)) * $direction;
        }

        if ($currentSort === 'next_update') {
            $aValue = (int) ($aPayload['nextScheduledUpdateTs'] ?? 0);
            $bValue = (int) ($bPayload['nextScheduledUpdateTs'] ?? 0);
            $aMissing = $aValue <= 0;
            $bMissing = $bValue <= 0;
            if ($aMissing !== $bMissing) {
                return $aMissing ? 1 : -1;
            }
        } else {
            $aValue = (int) ($aPayload['updatesCount'] ?? 0);
            $bValue = (int) ($bPayload['updatesCount'] ?? 0);
        }

        $result = $aValue <=> $bValue;
        if ($result === 0) {
            $result = strcasecmp((string) ($a['name'] ?? ''), (string) ($b['name'] ?? ''));
        }

        return $result * $direction;
    });
}

function mc_maintenance_icon(string $name): string
{
    $icons = [
        'plus' => '<path d="M12 5v14M5 12h14"/>',
        'upload' => '<path d="M12 3v12M7 8l5-5 5 5"/><path d="M5 21h14"/>',
        'download' => '<path d="M12 3v12M7 10l5 5 5-5"/><path d="M5 21h14"/>',
        'unlock' => '<rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 7.6-1.7"/>',
        'refresh' => '<path d="M20 11a8 8 0 0 0-14.9-4M4 5v5h5"/><path d="M4 13a8 8 0 0 0 14.9 4M20 19v-5h-5"/>',
        'sync-mcu' => '<path d="M20 11a8 8 0 0 0-14.9-4M4 5v5h5"/><path d="M4 13a8 8 0 0 0 14.9 4M20 19v-5h-5"/><path d="m13 7-4 6h3l-1 4 4-6h-3l1-4Z"/>',
        'bolt' => '<path d="M13 2 4 14h7l-1 8 10-13h-7l0-7Z"/>',
        'eye' => '<path d="M2 12s3.6-6 10-6 10 6 10 6-3.6 6-10 6S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>',
        'activity' => '<path d="M22 12h-4l-3 8L9 4l-3 8H2"/>',
        'edit' => '<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/>',
        'play' => '<path d="M7 4v16l13-8Z"/>',
        'stop' => '<circle cx="12" cy="12" r="9"/><path d="M9 9h6v6H9Z"/>',
        'trash' => '<path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M6 6l1 15h10l1-15"/><path d="M10 11v6M14 11v6"/>',
    ];

    return '<svg class="mc-maint-icon" viewBox="0 0 24 24" aria-hidden="true">' . ($icons[$name] ?? '') . '</svg>';
}

function mc_maintenance_signal_badge(array $summary): string
{
    $critical = max(0, (int) ($summary['critical'] ?? 0));
    $warning = max(0, (int) ($summary['warning'] ?? 0));
    $info = max(0, (int) ($summary['info'] ?? 0));
    $total = max(0, (int) ($summary['total'] ?? ($critical + $warning + $info)));

    if ($critical > 0) {
        $label = $critical . ' ' . ($critical === 1 ? 'critico' : 'critici');
        $class = 'is-critical';
    } elseif ($warning > 0) {
        $label = $warning . ' warning';
        $class = 'is-warning';
    } elseif ($info > 0) {
        $label = $info . ' info';
        $class = 'is-info';
    } else {
        $label = 'OK';
        $class = 'is-ok';
    }

    return '<span class="mc-maint-signal-badge ' . e($class) . '" data-critical="' . $critical . '" data-warning="' . $warning . '" data-info="' . $info . '" data-total="' . $total . '">' . e($label) . '</span>';
}

function mc_maintenance_sort_link(string $key, string $label, string $currentSort, string $currentDir): string
{
    $params = $_GET;
    $params['sort'] = $key;
    $params['dir'] = $currentSort === $key && $currentDir === 'asc' ? 'desc' : 'asc';
    $suffix = $currentSort === $key ? ($currentDir === 'asc' ? ' ^' : ' v') : '';
    $href = '?' . http_build_query($params);

    return '<a href="' . e($href) . '" title="Ordina per ' . e($label) . '">' . e($label . $suffix) . '</a>';
}

$activePage = 'maintenance';
$topbarExtraHtml = <<<'HTML'
<div class="mc-maint-progress-shell" id="mc-maint-progress-shell" hidden aria-live="polite">
    <div class="mc-maint-progress" hidden>
        <div class="mc-maint-progress-bar" id="mc-maint-progress-bar"></div>
    </div>
    <div class="mc-maint-progress-label" id="mc-maint-progress-label" hidden></div>
</div>
HTML;
include __DIR__ . '/partials/nav.php';
?>
<div class="mc-wrap mc-maint-wrap">
    <div class="mc-header">
        <div>
            <h1>Maintenance</h1>
            <p>Controllo centralizzato dei siti con Marrison Custom Updater client.</p>
        </div>
        <button type="button" class="mc-btn mc-btn-primary" id="mc-maint-open-add" title="Aggiungi un nuovo sito MCU" aria-label="Aggiungi un nuovo sito MCU">
            <?= mc_maintenance_icon('plus') ?> Aggiungi sito
        </button>
    </div>

    <?php if ($flash): ?>
        <div class="mc-msg <?= e($flash['type']) ?>"><?= e($flash['message']) ?></div>
    <?php endif; ?>

    <div class="mc-card mc-maint-toolbar">
        <button type="button" class="mc-btn mc-btn-primary" id="mc-maint-check-all" title="Verifica connessione e stato di tutti i siti" aria-label="Verifica connessione e stato di tutti i siti">Verifica tutti i siti</button>
        <button type="button" class="mc-btn mc-btn-ghost" id="mc-maint-check-selected" title="Verifica solo i siti selezionati" aria-label="Verifica solo i siti selezionati" disabled>Verifica selezionati</button>
        <button type="button" class="mc-btn mc-btn-ghost" id="mc-maint-monitor-tick" title="Esegue il monitor leggero sui siti dovuti" aria-label="Esegue il monitor leggero sui siti dovuti"><?= mc_maintenance_icon('activity') ?> Monitor leggero</button>
        <button type="button" class="mc-btn mc-btn-ghost" id="mc-maint-analyze-plugins" title="Analizza i plugin dei siti selezionati, oppure di tutti i siti mostrati; riutilizza il registro e la whitelist">Analizza i plugin</button>
        <button type="button" class="mc-btn mc-btn-ghost" id="mc-maint-sync-selected" title="Forza la sincronizzazione MCU sui siti selezionati" aria-label="Forza la sincronizzazione MCU sui siti selezionati" disabled><?= mc_maintenance_icon('sync-mcu') ?> Sincronizza selezionati</button>
        <button type="button" class="mc-btn mc-btn-primary" id="mc-maint-update-selected" title="Invia aggiornamenti ai siti selezionati" aria-label="Invia aggiornamenti ai siti selezionati" disabled>Aggiorna selezionati</button>
        <button type="button" class="mc-btn mc-btn-warning" id="mc-maint-update-pending" title="Aggiorna solo i siti con pallino giallo, rispettando le esclusioni" aria-label="Aggiorna solo i siti con pallino giallo, rispettando le esclusioni" disabled>Aggiorna siti con update</button>
        <button type="button" class="mc-btn mc-btn-warning" id="mc-maint-stop-checks" title="Interrompe l'azione generale dopo l'operazione in corso" aria-label="Interrompe l'azione generale dopo l'operazione in corso" hidden>Interrompi</button>
        <form method="post" enctype="multipart/form-data" class="mc-maint-inline-form">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="import_maintenance_config">
            <input type="file" name="maintenance_config[]" accept="application/json,.json" multiple required>
            <button type="submit" class="mc-btn mc-btn-ghost" title="Importa file JSON di configurazione MCU" aria-label="Importa file JSON di configurazione MCU"><?= mc_maintenance_icon('upload') ?> Carica configurazioni</button>
        </form>
        <form method="post" action="maintenance-report.php" class="mc-maint-inline-form">
            <?= csrf_field() ?>
            <button type="submit" class="mc-btn mc-btn-ghost" title="Scarica il report Maintenance in JSON" aria-label="Scarica il report Maintenance in JSON"><?= mc_maintenance_icon('download') ?> Scarica report</button>
        </form>
    </div>

    <form method="get" class="mc-card mc-maint-filter-bar" aria-label="Filtra siti per categoria e plugin">
        <?php if ($currentSort !== ''): ?><input type="hidden" name="sort" value="<?= e($currentSort) ?>"><?php endif; ?>
        <?php if ($currentDir !== 'asc'): ?><input type="hidden" name="dir" value="<?= e($currentDir) ?>"><?php endif; ?>
        <label for="mc-maint-category-filter">Categoria</label>
        <select id="mc-maint-category-filter" name="category">
            <option value="">Tutte le categorie</option>
            <?php foreach ($categories as $category): ?><option value="<?= e($category) ?>" <?= $currentCategory === $category ? 'selected' : '' ?>><?= e($category) ?></option><?php endforeach; ?>
        </select>
        <label for="mc-maint-plugin-filter">Plugin installato</label>
        <select id="mc-maint-plugin-filter" name="plugin" aria-describedby="mc-maint-plugin-help">
            <option value="">Tutti i plugin</option>
            <?php if ($currentPlugin !== '' && !isset($pluginCatalog['plugins'][$currentPlugin])): ?>
                <option value="<?= e($currentPlugin) ?>" selected>Plugin non presente negli inventari salvati</option>
            <?php endif; ?>
            <?php foreach ($pluginCatalog['plugins'] as $plugin): ?>
                <option value="<?= e($plugin['key']) ?>" <?= $currentPlugin === $plugin['key'] ? 'selected' : '' ?>><?= e($plugin['label']) ?></option>
            <?php endforeach; ?>
        </select>
        <button type="submit" class="mc-btn mc-btn-ghost">Filtra</button>
        <?php if ($currentCategory !== '' || $currentPlugin !== ''): ?><a class="mc-btn mc-btn-ghost" href="maintenance.php">Azzera filtri</a><?php endif; ?>
        <p id="mc-maint-plugin-help" class="mc-maint-filter-summary">
            Plugin in ordine alfabetico, ricavati dagli inventari salvati in Commander, inclusi quelli disattivati.
            Inventario disponibile per <?= count($categorySites) - $missingPluginInventories ?> di <?= count($categorySites) ?> siti<?= $currentCategory !== '' ? ' nella categoria selezionata' : '' ?>.
            <?php if ($missingPluginInventories > 0): ?>I siti senza inventario non sono inclusi nei risultati per plugin.<?php endif; ?>
            <?php if ($currentPlugin !== ''): ?>Siti trovati: <?= count($sites) ?>.<?php endif; ?>
            Dati al caricamento della pagina; non verificati in tempo reale.
        </p>
    </form>

    <div class="mc-stats">
        <div class="mc-stat"><span class="mc-stat-num" id="mc-maint-stat-total"><?= (int) $stats['total'] ?></span><span>Siti MCU</span></div>
        <div class="mc-stat"><span class="mc-stat-num" id="mc-maint-stat-updates"><?= (int) $stats['updates'] ?></span><span>Update aperti</span></div>
        <div class="mc-stat"><span class="mc-stat-num" id="mc-maint-stat-pending"><?= (int) $stats['pending'] ?></span><span>Richieste inviate</span></div>
        <div class="mc-stat"><span class="mc-stat-num" id="mc-maint-stat-failed"><?= (int) $stats['failed'] ?></span><span>Errori</span></div>
        <div class="mc-stat"><span class="mc-stat-num" id="mc-maint-stat-signals"><?= (int) ($stats['signals']['critical'] ?? 0) ?></span><span>Segnali critici</span></div>
    </div>

    <div class="mc-card mc-maint-table-card">
        <?php if (!$sites): ?>
            <div class="mc-empty"><?= $currentPlugin !== '' ? 'Nessun sito con questo plugin negli inventari salvati per i filtri selezionati.' : ($currentCategory !== '' ? 'Nessun sito nella categoria selezionata.' : 'Nessun sito MCU registrato.') ?></div>
        <?php else: ?>
            <table class="mc-table mc-maint-table">
                <colgroup>
                    <col class="mc-maint-col-status">
                    <col class="mc-maint-col-select">
                    <col class="mc-maint-col-name">
                    <col class="mc-maint-col-category">
                    <col class="mc-maint-col-server">
                    <col class="mc-maint-col-last">
                    <col class="mc-maint-col-wp">
                    <col class="mc-maint-col-client">
                    <col class="mc-maint-col-debug">
                    <col class="mc-maint-col-frequency">
                    <col class="mc-maint-col-last-update">
                    <col class="mc-maint-col-next-update">
                    <col class="mc-maint-col-updates">
                    <col class="mc-maint-col-signals">
                    <col class="mc-maint-col-error">
                    <col class="mc-maint-col-actions">
                </colgroup>
                <thead>
                    <tr>
                        <th class="mc-maint-th-status"></th>
                        <th class="mc-maint-th-select"><input type="checkbox" id="mc-maint-select-all" aria-label="Seleziona tutti i siti"></th>
                        <th><?= mc_maintenance_sort_link('name', 'Nome', $currentSort, $currentDir) ?></th>
                        <th>Categoria</th>
                        <th>Server</th>
                        <th>Ultima verifica</th>
                        <th>WP</th>
                        <th><?= mc_maintenance_sort_link('client', 'Client', $currentSort, $currentDir) ?></th>
                        <th>Debug</th>
                        <th>Frequenza MCU</th>
                        <th>Ultimo update</th>
                        <th><?= mc_maintenance_sort_link('next_update', 'Prossimo update schedulato', $currentSort, $currentDir) ?></th>
                        <th><?= mc_maintenance_sort_link('updates', 'Update', $currentSort, $currentDir) ?></th>
                        <th>Segnali</th>
                        <th>Errore</th>
                        <th>Azioni</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($sites as $index => $site):
                    $payload = $payloads[(int) $site['id']];
                    $rowClass = ((int) $index % 2) === 0 ? 'is-even' : 'is-odd';
                    $dashboardAvailable = !empty($payload['dashboardAccessAvailable']);
                    $localDeleteAvailable = !empty($payload['localDeleteAvailable']);
                    $deleteLabel = $localDeleteAvailable ? 'Rimuovi solo da Commander' : 'Elimina';
                ?>
                    <tr class="mc-maint-site-row <?= e($rowClass) ?>" data-site-id="<?= (int) $site['id'] ?>"
                        data-name="<?= e((string) $site['name']) ?>"
                        data-category="<?= e((string) ($site['category'] ?? '')) ?>"
                        data-server-code="<?= e((string) ($site['server_code'] ?? '')) ?>"
                        data-site-url="<?= e((string) $site['site_url']) ?>"
                        data-endpoint-url="<?= e((string) $site['endpoint_url']) ?>"
                        data-dashboard-access-url="<?= e((string) ($site['dashboard_access_url'] ?? '')) ?>"
                        data-dashboard-access-enabled="<?= !empty($site['dashboard_access_enabled']) ? '1' : '0' ?>"
                        data-supports-direct-plugin-update="<?= !empty($payload['supportsDirectPluginUpdate']) ? '1' : '0' ?>"
                        data-supports-direct-theme-update="<?= !empty($payload['supportsDirectThemeUpdate']) ? '1' : '0' ?>"
                        data-next-scheduled-update-ts="<?= (int) ($payload['nextScheduledUpdateTs'] ?? 0) ?>"
                        data-plugin-updates="<?= e(json_encode($payload['pluginUpdates'] ?? [], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: '[]') ?>"
                        data-update-items="<?= e(json_encode($payload['updateItems'] ?? [], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: '[]') ?>"
                        data-total-update-count="<?= (int) ($payload['totalUpdateCount'] ?? $payload['updatesCount']) ?>"
                        data-update-job="<?= e(json_encode($payload['updateJob'] ?? [], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: '{}') ?>"
                        data-note="<?= e((string) ($site['note'] ?? '')) ?>"
                        data-timeout="<?= (int) ($site['timeout_seconds'] ?? 15) ?>">
                        <td class="mc-maint-cell-status">
                            <span class="mc-maint-status-dot <?= e($payload['statusClass']) ?>" title="<?= e($payload['statusLabel']) ?>" aria-label="<?= e($payload['statusLabel']) ?>"></span>
                        </td>
                        <td class="mc-maint-cell-select">
                            <input type="checkbox" class="mc-maint-row-select" value="<?= (int) $site['id'] ?>" aria-label="Seleziona <?= e((string) $site['name']) ?>">
                        </td>
                        <td class="mc-maint-cell-name"><strong><a href="<?= e((string) $site['site_url']) ?>" target="_blank" rel="noopener noreferrer"><?= e((string) $site['name']) ?></a></strong><span class="mc-maint-row-state" hidden></span>
                            <?php if ($currentPlugin !== ''): $inventory = $pluginCatalog['sites'][(int) $site['id']]; ?>
                                <small class="mc-maint-inventory-date">Inventario: <?= e($inventory['dateLabel']) ?><?= $inventory['ageLabel'] !== '' ? ' (' . e($inventory['ageLabel']) . ')' : '' ?></small>
                            <?php endif; ?>
                            <span class="mc-maint-cell-pluginSecurity"><?= $payload['pluginSecurityHtml'] ?></span>
                        </td>
                        <td class="mc-maint-cell-category"><?php if (!empty($site['category'])): ?><span class="mc-maint-category-badge is-<?= e(strtolower((string) $site['category'])) ?>" title="<?= e((string) $site['category']) ?>"><?= e(strtoupper(substr((string) $site['category'], 0, 2))) ?></span><?php else: ?><span class="mc-maint-unassigned">-</span><?php endif; ?></td>
                        <td class="mc-maint-cell-serverCode"><?= e((string) ($site['server_code'] ?? '')) ?: '-' ?></td>
                        <td class="mc-maint-cell-lastChecked"><?= e($payload['lastChecked']) ?></td>
                        <td class="mc-maint-cell-wpVersion"><?= e($payload['wpVersion']) ?></td>
                        <td class="mc-maint-cell-clientVersion"><?= e($payload['clientVersion']) ?></td>
                        <td class="mc-maint-cell-debugState"><?= $payload['debugStatusHtml'] ?></td>
                        <td class="mc-maint-cell-mcuFrequency"><?= e($payload['mcuFrequency']) ?></td>
                        <td class="mc-maint-cell-lastMcuUpdate"><?= e($payload['lastMcuUpdate']) ?></td>
                        <td class="mc-maint-cell-nextScheduledUpdate"><?= e($payload['nextScheduledUpdate']) ?></td>
                        <td class="mc-maint-cell-updatesCount <?= e($payload['updatesClass']) ?>"><?= e($payload['updatesCount']) ?></td>
                        <td class="mc-maint-cell-signalSummary"><?= mc_maintenance_signal_badge($payload['signalSummary'] ?? []) ?></td>
                        <td class="mc-maint-cell-errorMessage"><?= $payload['errorFlagHtml'] ?></td>
                        <td class="mc-maint-actions">
                            <div class="mc-maint-actions-inner">
                                <?php if ($dashboardAvailable): ?>
                                    <form method="post" action="maintenance-dashboard.php" target="_blank" rel="noopener">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="site_id" value="<?= (int) $site['id'] ?>">
                                        <button type="submit" class="mc-maint-icon-button mc-maint-dashboard" title="Apri dashboard" aria-label="Apri dashboard"><?= mc_maintenance_icon('unlock') ?></button>
                                    </form>
                                <?php else: ?>
                                    <button type="button" class="mc-maint-icon-button" disabled title="Accesso dashboard non configurato" aria-label="Accesso dashboard non configurato"><?= mc_maintenance_icon('unlock') ?></button>
                                <?php endif; ?>
                                <button type="button" class="mc-maint-icon-button mc-maint-check-site" data-site-id="<?= (int) $site['id'] ?>" title="Verifica connessione" aria-label="Verifica connessione"><?= mc_maintenance_icon('refresh') ?></button>
                                <button type="button" class="mc-maint-icon-button mc-maint-force-sync" title="Sincronizza update MCU" aria-label="Sincronizza update MCU"><?= mc_maintenance_icon('bolt') ?></button>
                                <button type="button" class="mc-maint-icon-button mc-maint-details-toggle" title="Visualizza dettagli" aria-label="Visualizza dettagli" aria-expanded="false"><?= mc_maintenance_icon('eye') ?></button>
                                <a class="mc-maint-icon-button" href="maintenance-diagnostics.php?site_id=<?= (int) $site['id'] ?>" title="Diagnostica read-only" aria-label="Diagnostica read-only"><?= mc_maintenance_icon('activity') ?></a>
                                <button type="button" class="mc-maint-icon-button mc-maint-sync-diagnostics" title="Sincronizza snapshot e moduli diagnostici" aria-label="Sincronizza snapshot e moduli diagnostici"><?= mc_maintenance_icon('download') ?></button>
                                <button type="button" class="mc-maint-icon-button mc-maint-edit-site" title="Modifica" aria-label="Modifica"><?= mc_maintenance_icon('edit') ?></button>
                                <button type="button" class="mc-maint-icon-button mc-maint-run-update" title="Aggiorna plugin" aria-label="Aggiorna plugin"><?= mc_maintenance_icon('play') ?></button>
                                <button type="button" class="mc-maint-icon-button mc-maint-cancel-master-update" title="Cancella cron Master/Commander" aria-label="Cancella cron Master/Commander"><?= mc_maintenance_icon('stop') ?></button>
                                <form method="post" class="mc-maint-delete-form">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="delete_maintenance_site">
                                    <input type="hidden" name="id" value="<?= (int) $site['id'] ?>">
                                    <input type="hidden" name="force_local_delete" value="<?= $localDeleteAvailable ? '1' : '0' ?>">
                                    <button type="submit" class="mc-maint-icon-button mc-maint-delete" title="<?= e($deleteLabel) ?>" aria-label="<?= e($deleteLabel) ?>"><?= mc_maintenance_icon('trash') ?></button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <tr class="mc-maint-details-row <?= e($rowClass) ?>" data-site-id="<?= (int) $site['id'] ?>" hidden>
                        <td colspan="16"><div class="mc-maint-details-panel"><?= $payload['detailsHtml'] ?></div></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

    <div class="mc-card mc-maint-debug-card">
        <h3>Diagnostica Maintenance</h3>
        <form method="post" class="mc-maint-debug-form">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="save_maintenance_debug">
            <div class="mc-field mc-maint-check-field">
                <input type="checkbox" name="maintenance_debug_enabled" id="mc-maint-debug-enabled" value="1" <?= $maintenanceDebugEnabled ? 'checked' : '' ?>>
                <label for="mc-maint-debug-enabled">Abilita log debug limitati</label>
            </div>
            <button type="submit" class="mc-btn mc-btn-primary" title="Salva le impostazioni diagnostiche Maintenance" aria-label="Salva le impostazioni diagnostiche Maintenance">Salva impostazioni</button>
        </form>
    </div>
</div>

<div id="mc-maint-modal" class="mc-modal">
    <div class="mc-modal-box wide">
        <div class="mc-modal-head">
            <h2 id="mc-maint-modal-title">Aggiungi sito MCU</h2>
            <button type="button" class="mc-close" id="mc-maint-close" title="Chiudi finestra" aria-label="Chiudi finestra">&times;</button>
        </div>
        <form method="post" id="mc-maint-form">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="save_maintenance_site">
            <input type="hidden" name="id" id="mc-maint-id" value="0">
            <div class="mc-grid-2">
                <div class="mc-field">
                    <label>Nome sito</label>
                    <input type="text" name="name" id="mc-maint-name" required>
                </div>
                <div class="mc-field">
                    <label>URL sito</label>
                    <input type="url" name="site_url" id="mc-maint-site-url" placeholder="https://cliente.it" required>
                </div>
            </div>
            <div class="mc-grid-2">
                <div class="mc-field">
                    <label for="mc-maint-category">Categoria</label>
                    <select name="category" id="mc-maint-category">
                        <option value="">Non assegnata</option>
                        <?php foreach ($categories as $category): ?><option value="<?= e($category) ?>"><?= e($category) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="mc-field">
                    <label for="mc-maint-server-code">Server</label>
                    <input type="text" name="server_code" id="mc-maint-server-code" maxlength="2" pattern="[A-Za-z]{2}" placeholder="ES" autocomplete="off">
                </div>
            </div>
            <div class="mc-field">
                <label>Endpoint stato MCU</label>
                <input type="url" name="endpoint_url" id="mc-maint-endpoint-url" placeholder="https://cliente.it/wp-json/marrison-maintenance/v1/status" required>
            </div>
            <div class="mc-field">
                <label>Chiave connessione</label>
                <input type="password" name="secret" id="mc-maint-secret" autocomplete="new-password">
            </div>
            <div class="mc-field mc-maint-check-field">
                <input type="checkbox" name="dashboard_access_enabled" id="mc-maint-dashboard-enabled" value="1">
                <label for="mc-maint-dashboard-enabled">Abilita one-click dashboard</label>
            </div>
            <div class="mc-grid-2">
                <div class="mc-field">
                    <label>Endpoint one-click</label>
                    <input type="url" name="dashboard_access_url" id="mc-maint-dashboard-url" placeholder="https://cliente.it/wp-json/marrison-maintenance/v1/dashboard-access">
                </div>
                <div class="mc-field">
                    <label>Chiave one-click</label>
                    <input type="password" name="dashboard_access_key" id="mc-maint-dashboard-key" autocomplete="new-password">
                </div>
            </div>
            <div class="mc-grid-2">
                <div class="mc-field">
                    <label>Timeout</label>
                    <input type="number" name="timeout_seconds" id="mc-maint-timeout" min="3" max="60" value="15">
                </div>
                <div class="mc-field">
                    <label>Nota</label>
                    <input type="text" name="note" id="mc-maint-note">
                </div>
            </div>
            <div class="mc-modal-actions">
                <button type="button" class="mc-btn mc-btn-ghost" id="mc-maint-cancel" title="Annulla e chiudi senza salvare" aria-label="Annulla e chiudi senza salvare">Annulla</button>
                <button type="submit" class="mc-btn mc-btn-primary" title="Salva la configurazione del sito MCU" aria-label="Salva la configurazione del sito MCU">Salva sito</button>
            </div>
        </form>
    </div>
</div>

<script>
window.mcMaintenanceAdmin = <?= json_encode([
    'csrfToken' => csrf_token(),
    'checkUrl' => 'api/maintenance-check.php',
    'updateUrl' => 'api/maintenance-update.php',
    'updatePluginUrl' => 'api/maintenance-update-plugin.php',
    'updateExclusionUrl' => 'api/maintenance-update-exclusion.php',
    'syncUrl' => 'api/maintenance-force-sync.php',
    'startDiagnosticsUrl' => 'api/maintenance-start-diagnostics.php',
    'syncDiagnosticsUrl' => 'api/maintenance-sync-diagnostics.php',
    'frontendScanUrl' => 'api/maintenance-frontend-scan.php',
    'aiAnalysisUrl' => 'api/maintenance-ai-analysis.php',
    'debugToggleUrl' => 'api/maintenance-debug-toggle.php',
    'debugLogUrl' => 'api/maintenance-debug-log.php',
    'debugDownloadUrl' => 'api/maintenance-debug-log-download.php',
    'debugAiUrl' => 'api/maintenance-debug-ai.php',
    'debugDeleteUrl' => 'api/maintenance-debug-delete.php',
    'monitorTickUrl' => 'api/maintenance-monitor-tick.php',
    'cancelMasterUpdateUrl' => 'api/maintenance-cancel-master-update.php',
    'jobStatusUrl' => 'api/maintenance-job-status.php',
    'statsUrl' => 'api/maintenance-stats.php',
    'rowStatusUrl' => 'api/maintenance-row-status.php',
    'pluginSecurityUrl' => 'api/maintenance-plugin-security.php',
    'syncConcurrency' => 1,
    'messages' => [
        'checking' => 'Verifica in corso',
        'syncing' => 'Sincronizzazione MCU in corso',
        'cancelling' => 'Cancellazione cron Master/Commander in corso',
        'monitoring' => 'Monitoraggio leggero in corso',
        'failed' => 'Fallito',
        'checkFailed' => 'Verifica non riuscita.',
        'confirmDelete' => 'Rimuovere definitivamente questo sito MCU?',
        'deleteLabel' => 'Elimina',
        'localDeleteLabel' => 'Rimuovi solo da Commander',
        'confirmLocalDelete' => 'Rimuovere solo da Commander senza contattare MCU? La revoca remota dei repository non verra eseguita e l\'eventuale configurazione presente sul sito MCU restera invariata.',
        'confirmUpdate' => 'Aggiornare i plugin tramite Commander? Sui client MCU non aggiornati verra usato il vecchio flusso via cron.',
        'confirmSync' => 'Forzare su MCU il controllo aggiornamenti e aggiornare questa riga?',
        'confirmStartDiagnostics' => 'Avviare una nuova raccolta diagnostica su MCU? Non verra eseguito alcun aggiornamento.',
        'confirmSyncDiagnostics' => 'Scaricare da MCU lo snapshot diagnostico gia generato e i moduli disponibili? Non verra eseguito alcun aggiornamento.',
        'confirmFrontendScan' => 'Avviare lo scanner frontend esterno su questo sito?',
        'confirmAiAnalysis' => 'Generare una diagnosi AI sulle prove gia raccolte per questo sito?',
        'confirmCancelMasterUpdate' => 'Cancellare solo i cron e la richiesta Master/Commander pendente su questo client? Gli aggiornamenti schedulati MCU non verranno toccati.',
        'confirmDebugEnable' => 'Attivare WP_DEBUG sul sito client? Usalo solo per diagnosi mirate e ricordati di spegnerlo.',
        'confirmDebugDisable' => 'Disattivare WP_DEBUG sul sito client?',
        'confirmDebugAi' => 'Inviare manualmente il contenuto di debug.log al servizio AI configurato in Commander? Il log potrebbe contenere dati sensibili.',
        'confirmDebugDelete' => 'Eliminare debug.log sul sito client?',
        'allDone' => 'Verifica completata.',
        'selectedChecksDone' => 'Verifica selezionati completata.',
        'selectedSyncDone' => 'Sincronizzazione selezionati completata.',
        'selectedUpdatesDone' => 'Aggiornamento selezionati completato.',
        'pendingUpdatesDone' => 'Richieste ai siti con update elaborate. Verifica gli esiti nelle righe.',
        'noPendingUpdates' => 'Nessun sito con pallino giallo da aggiornare.',
        'confirmPendingUpdates' => 'Aggiornare {count} siti con pallino giallo? Saranno rispettate le esclusioni configurate.',
        'monitorDone' => 'Monitoraggio leggero completato.',
        'stopped' => 'Verifica interrotta.',
        'noSelection' => 'Seleziona almeno un sito.',
    ],
], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?>;

(function () {
    'use strict';

    var cfg = window.mcMaintenanceAdmin || {};
    var stopRequested = false;
    var groupActionRunning = false;
    var progressHideTimer = null;
    var trackedJobs = {};
    var rowRefreshRunning = false;
    var debugOutputCache = {};

    function qs(selector, context) {
        return (context || document).querySelector(selector);
    }

    function qsa(selector, context) {
        return Array.prototype.slice.call((context || document).querySelectorAll(selector));
    }

    function siteIdFromButton(button) {
        if (!button) return '';
        var direct = button.getAttribute('data-site-id') || '';
        if (direct) return direct;
        var row = button.closest('.mc-maint-site-row');
        if (row) return row.getAttribute('data-site-id') || '';
        var details = button.closest('.mc-maint-details-row');
        return details ? details.getAttribute('data-site-id') || '' : '';
    }

    function ensureButtonTooltips(context) {
        qsa('button, a.mc-btn, a.mc-maint-icon-button', context).forEach(function (element) {
            if (element.getAttribute('title')) return;
            var label = element.getAttribute('aria-label') || (element.textContent || '').replace(/\s+/g, ' ').trim();
            if (label) element.setAttribute('title', label);
        });
    }

    function activateDetailsTab(button) {
        var tabs = button ? button.closest('.mc-maint-tabs') : null;
        if (!tabs) return;

        var targetId = button.getAttribute('aria-controls') || '';
        qsa('.mc-maint-tab-button', tabs).forEach(function (tabButton) {
            var active = tabButton === button;
            tabButton.classList.toggle('is-active', active);
            tabButton.setAttribute('aria-selected', active ? 'true' : 'false');
            tabButton.setAttribute('tabindex', active ? '0' : '-1');
        });
        qsa('.mc-maint-tab-panel', tabs).forEach(function (panel) {
            var active = panel.getAttribute('id') === targetId;
            panel.hidden = !active;
            panel.classList.toggle('is-active', active);
        });
    }

    function iconFlag(hasError) {
        var label = hasError ? 'Errore presente: apri i dettagli riga.' : 'Nessun errore.';
        return '<span class="mc-maint-error-flag ' + (hasError ? 'is-error' : 'is-ok') + '" title="' + label + '" aria-label="' + label + '"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 21V4.5a1 1 0 0 1 1-1h8.3a2 2 0 0 1 1.4.6l.7.7a2 2 0 0 0 1.4.6H20v9h-2.2a2 2 0 0 1-1.4-.6l-.7-.7a2 2 0 0 0-1.4-.6H7V21H5Z"/></svg></span>';
    }

    function signalBadgeHtml(summary) {
        summary = summary || {};
        var critical = parseInt(summary.critical || '0', 10) || 0;
        var warning = parseInt(summary.warning || '0', 10) || 0;
        var info = parseInt(summary.info || '0', 10) || 0;
        var total = parseInt(summary.total || (critical + warning + info), 10) || 0;
        var label = 'OK';
        var className = 'is-ok';

        if (critical > 0) {
            label = critical + (critical === 1 ? ' critico' : ' critici');
            className = 'is-critical';
        } else if (warning > 0) {
            label = warning + ' warning';
            className = 'is-warning';
        } else if (info > 0) {
            label = info + ' info';
            className = 'is-info';
        }

        return '<span class="mc-maint-signal-badge ' + className + '" data-critical="' + critical + '" data-warning="' + warning + '" data-info="' + info + '" data-total="' + total + '">' + label + '</span>';
    }

    function formData(siteId) {
        var data = new window.FormData();
        data.append('csrf_token', cfg.csrfToken || '');
        data.append('site_id', siteId);
        return data;
    }

    function monitorFormData(limit, includeFrontend, includeAi) {
        var data = new window.FormData();
        data.append('csrf_token', cfg.csrfToken || '');
        data.append('limit', limit || 10);
        if (includeFrontend) data.append('frontend', '1');
        if (includeAi) data.append('ai', '1');
        return data;
    }

    function debugFormData(siteId, options) {
        var data = formData(siteId);
        options = options || {};
        Object.keys(options).forEach(function (key) {
            data.append(key, options[key]);
        });
        return data;
    }

    function escapeHtml(value) {
        return String(value || '').replace(/[&<>"']/g, function (char) {
            return {
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#039;'
            }[char];
        });
    }

    function decodeBase64Text(value) {
        if (!value) return '';
        try {
            var binary = window.atob(value);
            if (window.TextDecoder) {
                var bytes = new Uint8Array(binary.length);
                for (var i = 0; i < binary.length; i += 1) {
                    bytes[i] = binary.charCodeAt(i);
                }
                return new window.TextDecoder('utf-8', { fatal: false }).decode(bytes);
            }
            return binary;
        } catch (error) {
            return '';
        }
    }

    function debugOutput(siteId) {
        return qs('.mc-maint-debug-output[data-site-id="' + siteId + '"]');
    }

    function setDebugOutputHtml(siteId, html) {
        var output = debugOutput(siteId);
        if (!output) return;
        output.innerHTML = html;
        debugOutputCache[siteId] = html;
    }

    function captureDebugOutput(siteId) {
        var output = debugOutput(siteId);
        if (output && output.innerHTML.trim() !== '') {
            debugOutputCache[siteId] = output.innerHTML;
        }
    }

    function restoreDebugOutput(siteId, context) {
        var html = debugOutputCache[siteId] || '';
        if (!html) return;
        var output = qs('.mc-maint-debug-output[data-site-id="' + siteId + '"]', context || document);
        if (output) output.innerHTML = html;
    }

    function clearDebugOutput(siteId) {
        delete debugOutputCache[siteId];
        var output = debugOutput(siteId);
        if (output) output.innerHTML = '';
    }

    function setButtonLoading(button, active, label) {
        if (!button) return;
        if (active) {
            if (!button.getAttribute('data-original-html')) {
                button.setAttribute('data-original-html', button.innerHTML);
            }
            button.disabled = true;
            button.classList.add('is-loading');
            button.innerHTML = '<span class="mc-maint-btn-spinner" aria-hidden="true"></span><span>' + escapeHtml(label || 'Attendere') + '</span>';
            return;
        }

        var original = button.getAttribute('data-original-html');
        if (original !== null) {
            button.innerHTML = original;
            button.removeAttribute('data-original-html');
        }
        button.disabled = false;
        button.classList.remove('is-loading');
    }

    function renderDebugLoading(siteId, title, text) {
        setDebugOutputHtml(siteId, '<div class="mc-maint-debug-result is-loading">'
            + '<div class="mc-maint-debug-loader">'
            + '<span class="mc-maint-spinner" aria-hidden="true"></span>'
            + '<div><strong>' + escapeHtml(title || 'Operazione in corso') + '</strong><span>' + escapeHtml(text || 'Attendere il completamento.') + '</span></div>'
            + '</div>'
            + '</div>');
    }

    function renderDebugError(siteId, message) {
        setDebugOutputHtml(siteId, '<div class="mc-maint-debug-result">'
            + '<div class="mc-maint-debug-ai-warning">' + escapeHtml(message || 'Operazione non riuscita.') + '</div>'
            + '</div>');
    }

    function parseJsonObject(value) {
        var text = String(value || '').trim();
        if (!text) return null;
        try {
            var parsed = JSON.parse(text);
            return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : null;
        } catch (error) {
            var start = text.indexOf('{');
            var end = text.lastIndexOf('}');
            if (start >= 0 && end > start) {
                try {
                    var extracted = JSON.parse(text.slice(start, end + 1));
                    return extracted && typeof extracted === 'object' && !Array.isArray(extracted) ? extracted : null;
                } catch (ignored) {}
            }
        }
        return null;
    }

    function debugAiResponse(result) {
        result = result || {};
        if (result.response && typeof result.response === 'object' && !Array.isArray(result.response)) {
            return result.response;
        }
        var stored = result.analysis && result.analysis.response && typeof result.analysis.response === 'object'
            ? result.analysis.response
            : null;
        if (stored && stored.analysis && typeof stored.analysis === 'object') {
            return stored.analysis;
        }
        if (stored) {
            return stored;
        }
        return parseJsonObject(result.message || '') || {};
    }

    function debugAiText(value) {
        if (value === null || value === undefined) return '';
        if (Array.isArray(value)) {
            return value.map(debugAiText).filter(Boolean).join('; ');
        }
        if (typeof value === 'object') {
            return Object.keys(value).map(function (key) {
                return key.replace(/_/g, ' ') + ': ' + debugAiText(value[key]);
            }).filter(Boolean).join(' · ');
        }
        return String(value).replace(/\s+/g, ' ').trim();
    }

    function debugAiList(value) {
        if (value === null || value === undefined || value === '') return [];
        return Array.isArray(value) ? value : [value];
    }

    function renderDebugAiSection(title, value) {
        var items = debugAiList(value).map(debugAiText).filter(Boolean);
        if (!items.length) return '';
        if (items.length === 1) {
            return '<section class="mc-maint-debug-ai-section"><h5>' + escapeHtml(title) + '</h5><p>' + escapeHtml(items[0]) + '</p></section>';
        }
        return '<section class="mc-maint-debug-ai-section"><h5>' + escapeHtml(title) + '</h5><ul>'
            + items.map(function (item) { return '<li>' + escapeHtml(item) + '</li>'; }).join('')
            + '</ul></section>';
    }

    function debugAiSeverityClass(severity) {
        severity = String(severity || '').toLowerCase();
        return severity === 'critical' || severity === 'warning' ? 'is-' + severity : 'is-info';
    }

    function debugAiConfidenceLabel(value) {
        if (value === null || value === undefined || value === '') return '';
        if (typeof value === 'number' || String(value).match(/^\d+(\.\d+)?$/)) {
            var number = parseFloat(value);
            if (number <= 1) number *= 100;
            return Math.round(number) + '% confidenza';
        }
        return String(value) + ' confidenza';
    }

    function updateItemLabel(item) {
        if (!item) return 'Update';
        return item.name || item.slug || item.file || 'Update';
    }

    function parseUpdateItems(row) {
        if (!row) return [];
        try {
            var parsed = JSON.parse(row.getAttribute('data-update-items') || '[]');
            return Array.isArray(parsed) ? parsed.filter(function (item) {
                return item && (item.file || item.slug);
            }) : [];
        } catch (error) {
            return [];
        }
    }

    function parseUpdateJob(row) {
        if (!row) return null;
        try {
            var parsed = JSON.parse(row.getAttribute('data-update-job') || '{}');
            return parsed && parsed.remoteJobId ? parsed : null;
        } catch (error) {
            return null;
        }
    }

    function supportsDirectPluginUpdate(row) {
        return !!(row && cfg.updatePluginUrl && row.getAttribute('data-supports-direct-plugin-update') === '1');
    }

    function supportsDirectThemeUpdate(row) {
        return !!(row && cfg.updatePluginUrl && row.getAttribute('data-supports-direct-theme-update') === '1');
    }

    function supportsDirectUpdateItem(row, item) {
        var type = String((item && item.update_type) || 'plugin').toLowerCase();
        return type === 'theme' ? supportsDirectThemeUpdate(row) : supportsDirectPluginUpdate(row);
    }

    function isMcuSelfPlugin(plugin) {
        var slug = String((plugin && plugin.slug) || '').toLowerCase();
        var file = String((plugin && plugin.file) || '').toLowerCase();
        return slug === 'marrison-custom-updater' || file.indexOf('marrison-custom-updater/') === 0;
    }

    function updateItemFormData(siteId, item, jobId, step, total) {
        var data = formData(siteId);
        data.append('update_type', item.update_type || 'plugin');
        data.append('plugin_file', item.file || '');
        data.append('slug', item.slug || '');
        data.append('name', item.name || '');
        data.append('type', item.type || '');
        data.append('current_version', item.current_version || '');
        data.append('new_version', item.new_version || '');
        data.append('package', item.package || '');
        data.append('job_id', jobId || '');
        data.append('step', step);
        data.append('total', total);
        return data;
    }

    function jobFormData(siteId, jobId) {
        var data = formData(siteId);
        if (jobId) data.append('job_id', jobId);
        return data;
    }

    function detailsRowFor(row) {
        if (!row) return null;
        var siteId = row.getAttribute('data-site-id') || '';
        return siteId ? qs('.mc-maint-details-row[data-site-id="' + siteId + '"]') : null;
    }

    function setRowActivity(row, state, message) {
        if (!row) return;
        var active = state === 'busy' || state === 'job';
        var details = detailsRowFor(row);
        var label = qs('.mc-maint-row-state', row);
        var text = message || (state === 'job' ? 'Job MCU in osservazione' : 'Operazione in corso');

        row.classList.toggle('is-row-busy', state === 'busy');
        row.classList.toggle('is-job-pending', state === 'job');
        row.setAttribute('aria-busy', active ? 'true' : 'false');
        if (details) {
            details.classList.toggle('is-row-busy', state === 'busy');
            details.classList.toggle('is-job-pending', state === 'job');
        }
        if (label) {
            label.hidden = !active;
            label.textContent = active ? text : '';
            label.setAttribute('title', active ? text : '');
        }
        updateSelectionControls();
    }

    function clearRowActivity(row) {
        setRowActivity(row, '', '');
    }

    function setChecking(row, message) {
        var dot = qs('.mc-maint-status-dot', row);
        if (!dot) return;
        var label = message || cfg.messages.checking;
        dot.className = 'mc-maint-status-dot is-checking';
        dot.setAttribute('title', label);
        dot.setAttribute('aria-label', label);
        setRowActivity(row, 'busy', label);
    }

    function setJobWaiting(row, message) {
        var dot = qs('.mc-maint-status-dot', row);
        var label = message || 'Job MCU in osservazione';
        if (dot) {
            dot.className = 'mc-maint-status-dot is-pending';
            dot.setAttribute('title', label);
            dot.setAttribute('aria-label', label);
        }
        setRowActivity(row, 'job', label);
    }

    function setProgress(done, total, message) {
        var shell = qs('#mc-maint-progress-shell');
        var wrapper = qs('.mc-maint-progress');
        var bar = qs('#mc-maint-progress-bar');
        var label = qs('#mc-maint-progress-label');
        var percent = total > 0 ? Math.round((done / total) * 100) : 0;
        if (progressHideTimer) {
            window.clearTimeout(progressHideTimer);
            progressHideTimer = null;
        }
        if (shell) shell.hidden = false;
        if (wrapper) {
            wrapper.hidden = false;
            wrapper.classList.toggle('is-indeterminate', total > 0 && done <= 0);
        }
        if (label) label.hidden = false;
        if (bar) bar.style.width = percent + '%';
        if (label) label.textContent = message || (done + ' / ' + total);
    }

    function hideProgressSoon() {
        if (progressHideTimer) window.clearTimeout(progressHideTimer);
        progressHideTimer = window.setTimeout(function () {
            var shell = qs('#mc-maint-progress-shell');
            var wrapper = qs('.mc-maint-progress');
            var bar = qs('#mc-maint-progress-bar');
            var label = qs('#mc-maint-progress-label');
            if (wrapper) {
                wrapper.hidden = true;
                wrapper.classList.remove('is-indeterminate');
            }
            if (label) {
                label.hidden = true;
                label.textContent = '';
            }
            if (bar) bar.style.width = '0%';
            if (shell) shell.hidden = true;
            progressHideTimer = null;
        }, 1000);
    }

    function setStopButton(active) {
        var stop = qs('#mc-maint-stop-checks');
        if (!stop) return;
        stop.hidden = !active;
        stop.disabled = !active;
    }

    function applyStats(stats) {
        if (!stats) return;
        var totalEl = qs('#mc-maint-stat-total');
        var updatesEl = qs('#mc-maint-stat-updates');
        var pendingEl = qs('#mc-maint-stat-pending');
        var failedEl = qs('#mc-maint-stat-failed');
        var signalsEl = qs('#mc-maint-stat-signals');

        if (totalEl) totalEl.textContent = parseInt(stats.total || '0', 10) || 0;
        if (updatesEl) updatesEl.textContent = parseInt(stats.updates || '0', 10) || 0;
        if (pendingEl) pendingEl.textContent = parseInt(stats.pending || '0', 10) || 0;
        if (failedEl) failedEl.textContent = parseInt(stats.failed || '0', 10) || 0;
        if (signalsEl) signalsEl.textContent = parseInt((stats.signals && stats.signals.critical) || '0', 10) || 0;
    }

    function refreshStatsFromDom() {
        var updates = 0;
        var pending = 0;
        var failed = 0;
        var criticalSignals = 0;
        var rows = qsa('.mc-maint-site-row');

        rows.forEach(function (row) {
            var updateCell = qs('.mc-maint-cell-updatesCount', row);
            var dot = qs('.mc-maint-status-dot', row);
            var signalBadge = qs('.mc-maint-signal-badge', row);
            updates += parseInt(updateCell ? updateCell.textContent || '0' : '0', 10) || 0;
            if (dot && dot.classList.contains('is-pending')) pending += 1;
            if (dot && dot.classList.contains('is-failed')) failed += 1;
            criticalSignals += parseInt(signalBadge ? signalBadge.getAttribute('data-critical') || '0' : '0', 10) || 0;
        });

        var totalEl = qs('#mc-maint-stat-total');
        var updatesEl = qs('#mc-maint-stat-updates');
        var pendingEl = qs('#mc-maint-stat-pending');
        var failedEl = qs('#mc-maint-stat-failed');
        var signalsEl = qs('#mc-maint-stat-signals');

        if (totalEl) totalEl.textContent = rows.length;
        if (updatesEl) updatesEl.textContent = updates;
        if (pendingEl) pendingEl.textContent = pending;
        if (failedEl) failedEl.textContent = failed;
        if (signalsEl) signalsEl.textContent = criticalSignals;
    }

    function refreshStats() {
        if (!cfg.statsUrl) {
            refreshStatsFromDom();
            return Promise.resolve();
        }

        var data = new window.FormData();
        data.append('csrf_token', cfg.csrfToken || '');

        return window.fetch(cfg.statsUrl, {
            method: 'POST',
            credentials: 'same-origin',
            body: data
        }).then(function (response) {
            return response.json();
        }).then(function (json) {
            if (!json || !json.success) {
                throw new Error('stats_failed');
            }
            applyStats(json.data || {});
        }).catch(function () {
            refreshStatsFromDom();
        });
    }

    function updateRow(siteId, payload) {
        var row = qs('.mc-maint-site-row[data-site-id="' + siteId + '"]');
        var details = qs('.mc-maint-details-row[data-site-id="' + siteId + '"]');
        if (!row || !payload) return;

        var deleteForm = qs('.mc-maint-delete-form', row);
        if (deleteForm) {
            var localDeleteInput = qs('input[name="force_local_delete"]', deleteForm);
            var deleteButton = qs('.mc-maint-delete', deleteForm);
            var localDeleteAvailable = !!payload.localDeleteAvailable;
            if (localDeleteInput) localDeleteInput.value = localDeleteAvailable ? '1' : '0';
            if (deleteButton) {
                var deleteLabel = localDeleteAvailable ? cfg.messages.localDeleteLabel : cfg.messages.deleteLabel;
                deleteButton.setAttribute('title', deleteLabel);
                deleteButton.setAttribute('aria-label', deleteLabel);
            }
        }

        row.setAttribute('data-supports-direct-plugin-update', payload.supportsDirectPluginUpdate ? '1' : '0');
        row.setAttribute('data-supports-direct-theme-update', payload.supportsDirectThemeUpdate ? '1' : '0');
        row.setAttribute('data-plugin-updates', JSON.stringify(payload.pluginUpdates || []));
        row.setAttribute('data-update-items', JSON.stringify(payload.updateItems || []));
        row.setAttribute('data-total-update-count', parseInt(payload.totalUpdateCount || payload.updatesCount || '0', 10) || 0);
        row.setAttribute('data-update-job', JSON.stringify(payload.updateJob || {}));
        row.setAttribute('data-next-scheduled-update-ts', parseInt(payload.nextScheduledUpdateTs || '0', 10) || 0);

        var dot = qs('.mc-maint-status-dot', row);
        if (dot) {
            dot.className = 'mc-maint-status-dot ' + (payload.statusClass || 'is-never');
            dot.setAttribute('title', payload.statusLabel || '');
            dot.setAttribute('aria-label', payload.statusLabel || '');
        }

        [
            'lastChecked',
            'wpVersion',
            'clientVersion',
            'debugState',
            'mcuFrequency',
            'lastMcuUpdate',
            'nextScheduledUpdate',
            'updatesCount'
        ].forEach(function (key) {
            var cell = qs('.mc-maint-cell-' + key, row);
            if (!cell) return;
            if (key === 'debugState') {
                cell.innerHTML = payload.debugStatusHtml || '';
            } else {
                cell.textContent = payload[key] || '';
            }
            if (key === 'updatesCount') {
                cell.classList.toggle('has-updates', parseInt(payload[key] || '0', 10) > 0);
            }
        });

        var errorCell = qs('.mc-maint-cell-errorMessage', row);
        if (errorCell) {
            errorCell.innerHTML = payload.errorFlagHtml || iconFlag(!!payload.errorMessage);
        }

        var signalCell = qs('.mc-maint-cell-signalSummary', row);
        if (signalCell) {
            signalCell.innerHTML = signalBadgeHtml(payload.signalSummary || {});
        }
        var securityCell = qs('.mc-maint-cell-pluginSecurity', row);
        if (securityCell && payload.pluginSecurityHtml !== undefined) {
            securityCell.innerHTML = payload.pluginSecurityHtml;
            securityCell.classList.remove('is-security-error');
        }

        if (details) {
            var panel = qs('.mc-maint-details-panel', details);
            if (panel) {
                captureDebugOutput(siteId);
                var activeTab = qs('.mc-maint-tab-button.is-active', panel);
                var activeKey = activeTab ? activeTab.getAttribute('data-maint-tab') || '' : '';
                panel.innerHTML = payload.detailsHtml || '';
                ensureButtonTooltips(panel);
                if (activeKey) {
                    var nextTab = qs('.mc-maint-tab-button[data-maint-tab="' + activeKey + '"]', panel);
                    if (nextTab) activateDetailsTab(nextTab);
                }
                restoreDebugOutput(siteId, panel);
            }
        }

        if (payload.updateJob && payload.updateJob.remoteJobId && !payload.updateJob.terminal) {
            setJobWaiting(row, jobDisplayMessage(payload.updateJob));
        } else {
            clearRowActivity(row);
        }

        refreshStats();
    }

    function postJson(url, data) {
        return window.fetch(url, {
            method: 'POST',
            credentials: 'same-origin',
            body: data
        }).then(function (response) {
            return response.json();
        }).then(function (json) {
            if (!json || !json.success) {
                throw new Error(json && json.error ? json.error : cfg.messages.checkFailed);
            }
            return json.data;
        });
    }

    function pluginSecurityAction(siteId, action, button, quiet) {
        var row = qs('.mc-maint-site-row[data-site-id="' + siteId + '"]');
        if (row && row.classList.contains('is-row-busy')) return Promise.resolve();
        var data = formData(siteId);
        data.append('action', action);
        if (button) {
            data.append('fingerprint', button.getAttribute('data-fingerprint') || '');
            data.append('confirm_file', button.getAttribute('data-plugin-file') || '');
            data.append('notice_token', button.getAttribute('data-notice-token') || '');
            button.disabled = true;
        }
        if (row) setRowActivity(row, 'busy', action === 'analyze' ? 'Analisi plugin in corso' : 'Operazione plugin in corso');
        return window.fetch(cfg.pluginSecurityUrl, {method: 'POST', credentials: 'same-origin', body: data})
            .then(function (response) { return response.json(); })
            .then(function (json) {
                var result = json.data || {};
                if (result.payload) updateRow(siteId, result.payload);
                if (!json.success) throw new Error(json.error || 'Operazione plugin non riuscita.');
                if (!quiet) window.alert(result.message || 'Operazione completata.');
                var ids = result.affectedSiteIds || [];
                return ids.reduce(function (promise, id, index) {
                    return index % 50 ? promise : promise.then(function () { return refreshRowsFromCommander(ids.slice(index, index + 50)); });
                }, Promise.resolve());
            }).catch(function (error) {
                if (row) clearRowActivity(row);
                var cell = row ? qs('.mc-maint-cell-pluginSecurity', row) : null;
                if (cell) {
                    cell.textContent = 'Analisi/operazione non completata: ' + error.message;
                    cell.classList.add('is-security-error');
                }
                if (!quiet) window.alert(error.message);
            }).then(function () { if (button) button.disabled = false; });
    }

    function requestJson(url, siteId) {
        return postJson(url, formData(siteId));
    }

    function jobKey(siteId, jobId) {
        return String(siteId || '') + ':' + String(jobId || '');
    }

    function isTerminalJob(job) {
        return !!(job && job.terminal);
    }

    function jobPollDelay(job) {
        var seconds = parseInt((job && job.pollDelaySeconds) || '2', 10) || 2;
        return Math.max(2, Math.min(120, seconds)) * 1000;
    }

    function jobDisplayMessage(job) {
        if (!job) return 'Job MCU in osservazione.';
        var parts = [];
        if (job.statusLabel) parts.push(job.statusLabel);
        if (job.stageLabel) parts.push(job.stageLabel);
        var message = parts.join(' · ');
        if (job.message) message += (message ? ': ' : '') + job.message;
        return message || 'Job MCU in osservazione.';
    }

    function updateTrackedJobsProgress() {
        var keys = Object.keys(trackedJobs);
        if (!keys.length) return;

        keys.forEach(function (key) {
            var tracked = trackedJobs[key] || {};
            if (isTerminalJob(tracked.job || {})) return;
            var row = qs('.mc-maint-site-row[data-site-id="' + tracked.siteId + '"]');
            if (row) setJobWaiting(row, jobDisplayMessage(tracked.job || {}));
        });
    }

    function rowsNeedingStoredRefresh() {
        var rows = [];
        qsa('.mc-maint-site-row').forEach(function (row) {
            if (row.classList.contains('is-row-busy')) return;
            var dot = qs('.mc-maint-status-dot', row);
            var shouldRefresh = row.classList.contains('is-job-pending')
                || (dot && (dot.classList.contains('is-failed') || dot.classList.contains('is-pending') || dot.classList.contains('is-checking')));
            if (shouldRefresh) rows.push(row);
        });
        return rows;
    }

    function refreshRowsFromCommander(siteIds) {
        if (!cfg.rowStatusUrl || rowRefreshRunning) return Promise.resolve();
        siteIds = (siteIds || []).filter(Boolean).filter(function (siteId, index, all) {
            return all.indexOf(siteId) === index;
        }).slice(0, 50);
        if (!siteIds.length) return Promise.resolve();

        var data = new window.FormData();
        data.append('csrf_token', cfg.csrfToken || '');
        siteIds.forEach(function (siteId) {
            data.append('site_ids[]', siteId);
        });

        rowRefreshRunning = true;
        return postJson(cfg.rowStatusUrl, data).then(function (payloads) {
            Object.keys(payloads || {}).forEach(function (siteId) {
                updateRow(siteId, payloads[siteId]);
            });
        }).catch(function () {
            return null;
        }).then(function () {
            rowRefreshRunning = false;
        });
    }

    function refreshProblemRowsFromCommander() {
        var ids = rowsNeedingStoredRefresh().map(function (row) {
            return row.getAttribute('data-site-id') || '';
        });
        return refreshRowsFromCommander(ids);
    }

    function trackUpdateJob(siteId, job) {
        if (!cfg.jobStatusUrl || !job || !job.remoteJobId || isTerminalJob(job)) return;

        var key = jobKey(siteId, job.remoteJobId);
        if (trackedJobs[key] && trackedJobs[key].timer) {
            window.clearTimeout(trackedJobs[key].timer);
        }

        trackedJobs[key] = {
            siteId: siteId,
            jobId: job.remoteJobId,
            job: job,
            timer: null,
            failures: 0
        };

        var row = qs('.mc-maint-site-row[data-site-id="' + siteId + '"]');
        if (row) setJobWaiting(row, jobDisplayMessage(job));
        scheduleJobPoll(key, jobPollDelay(job));
        updateTrackedJobsProgress();
    }

    function scheduleJobPoll(key, delayMs) {
        if (!trackedJobs[key]) return;
        trackedJobs[key].timer = window.setTimeout(function () {
            pollTrackedJob(key);
        }, delayMs);
    }

    function pollTrackedJob(key) {
        var tracked = trackedJobs[key];
        if (!tracked) return;

        postJson(cfg.jobStatusUrl, jobFormData(tracked.siteId, tracked.jobId)).then(function (data) {
            var row = qs('.mc-maint-site-row[data-site-id="' + tracked.siteId + '"]');
            var job = data.job || {};
            tracked.failures = 0;

            if (data.payload) {
                updateRow(tracked.siteId, data.payload);
            }
            if (job.remoteJobId) {
                tracked.job = job;
                if (row) {
                    row.setAttribute('data-update-job', JSON.stringify(job));
                    if (!isTerminalJob(job)) setJobWaiting(row, jobDisplayMessage(job));
                }
            }

            if (!job.remoteJobId || isTerminalJob(job)) {
                if (job.status === 'failed') {
                    markFailed(tracked.siteId, job.message || job.lastErrorMessage || cfg.messages.failed);
                } else if (job.status === 'completed') {
                    if (row) setChecking(row, 'Job completato, aggiorno la riga');
                    checkSite(tracked.siteId);
                }
                window.setTimeout(function () {
                    delete trackedJobs[key];
                    updateTrackedJobsProgress();
                }, 1200);
                return;
            }

            updateTrackedJobsProgress();
            scheduleJobPoll(key, jobPollDelay(job));
        }).catch(function (error) {
            tracked.failures += 1;
            var delay = Math.min(300000, Math.pow(2, Math.min(5, tracked.failures)) * 5000);
            var row = qs('.mc-maint-site-row[data-site-id="' + tracked.siteId + '"]');
            if (row) setJobWaiting(row, 'Follow-up job MCU: ' + error.message);
            scheduleJobPoll(key, delay);
        });
    }

    function resumeTrackedUpdateJobs() {
        qsa('.mc-maint-site-row').forEach(function (row) {
            var job = parseUpdateJob(row);
            if (!job || job.terminal) return;
            var siteId = row.getAttribute('data-site-id') || '';
            if (!siteId) return;
            setJobWaiting(row, jobDisplayMessage(job));
            trackUpdateJob(siteId, job);
        });
    }

    function diagnosticSyncMessage(result) {
        var modules = result && result.data && result.data.modules ? result.data.modules : null;
        if (!modules) return 'Snapshot diagnostico sincronizzato.';

        var total = parseInt(modules.total_count || '0', 10) || 0;
        var synced = parseInt(modules.synced_count || '0', 10) || 0;
        var alreadySynced = parseInt(modules.already_synced_count || '0', 10) || 0;
        var failed = parseInt(modules.failed_count || '0', 10) || 0;
        var message = 'Snapshot diagnostico: ' + (synced + alreadySynced) + ' / ' + total + ' moduli in Commander';
        if (synced > 0) message += ' (' + synced + ' nuovi)';
        if (failed > 0) message += ', ' + failed + ' non ancora scaricabili';
        return message + '.';
    }

    function diagnosticStartMessage(result) {
        var message = result && result.message ? result.message : 'Snapshot diagnostico accodato.';
        var payload = result && result.response_data && result.response_data.data ? result.response_data.data : {};
        var nextRun = parseInt(payload.next_run || '0', 10) || 0;
        if (nextRun > 0) {
            var date = new Date(nextRun * 1000);
            message += ' Prossimo avvio: ' + date.toLocaleString() + '.';
        }
        return message;
    }

    function markFailed(siteId, message) {
        var row = qs('.mc-maint-site-row[data-site-id="' + siteId + '"]');
        if (!row) return;
        var dot = qs('.mc-maint-status-dot', row);
        var errorCell = qs('.mc-maint-cell-errorMessage', row);
        if (dot) {
            dot.className = 'mc-maint-status-dot is-failed';
            dot.setAttribute('title', message || cfg.messages.failed);
            dot.setAttribute('aria-label', message || cfg.messages.failed);
        }
        if (errorCell) {
            errorCell.innerHTML = iconFlag(true);
        }
        clearRowActivity(row);

        refreshStats();
    }

    function setExclusionToggleError(toggle, message) {
        var item = toggle ? toggle.closest('li') : null;
        if (!item) return;
        var error = qs('.mc-maint-exclusion-error', item);
        if (!message) {
            if (error) error.remove();
            item.classList.remove('has-exclusion-error');
            return;
        }
        if (!error) {
            error = document.createElement('small');
            error.className = 'mc-maint-exclusion-error';
            item.appendChild(error);
        }
        error.textContent = message;
        item.classList.add('has-exclusion-error');
    }

    function checkSite(siteId) {
        var row = qs('.mc-maint-site-row[data-site-id="' + siteId + '"]');
        if (row) setChecking(row);
        return requestJson(cfg.checkUrl, siteId).then(function (payload) {
            updateRow(siteId, payload);
            return payload;
        }).catch(function (error) {
            markFailed(siteId, error.message);
        });
    }

    function runUpdate(siteId) {
        var row = qs('.mc-maint-site-row[data-site-id="' + siteId + '"]');
        var allItems = parseUpdateItems(row);
        var items = allItems.filter(function (item) {
            return item.included !== false;
        });
        var totalUpdateCount = row ? parseInt(row.getAttribute('data-total-update-count') || '0', 10) || 0 : 0;
        var nonDetailedCount = Math.max(0, totalUpdateCount - allItems.length);
        if (allItems.length && !items.length) {
            if (nonDetailedCount <= 0) {
                setProgress(1, 1, 'Nessun aggiornamento selezionato per questo sito.');
                hideProgressSoon();
                return Promise.resolve(null);
            }

            return runLegacyUpdate(siteId, row, 'Invio richiesta update legacy per update non dettagliati');
        }
        if (items.length) {
            var directItems = items.filter(function (item) {
                return !isMcuSelfPlugin(item) && supportsDirectUpdateItem(row, item);
            });
            var legacyItemCount = items.length - directItems.length + nonDetailedCount;
            if (directItems.length > 0) {
                return runDirectUpdates(siteId, row, directItems, legacyItemCount).then(function (data) {
                    if (!data || stopRequested || legacyItemCount <= 0) return data;
                    return runLegacyUpdate(siteId, row, 'Invio richiesta update legacy per traduzioni o update non dettagliati');
                });
            }
        }

        return runLegacyUpdate(siteId, row, 'Invio richiesta update legacy');
    }

    function runLegacyUpdate(siteId, row, progressMessage) {
        if (row) setChecking(row, 'Richiesta aggiornamento legacy');
        setProgress(0, 1, progressMessage || 'Invio richiesta update legacy');
        return requestJson(cfg.updateUrl, siteId).then(function (data) {
            updateRow(siteId, data.payload || {});
            var job = data.job || (data.payload && data.payload.updateJob) || null;
            if (job && job.remoteJobId && !job.terminal) {
                trackUpdateJob(siteId, job);
                hideProgressSoon();
            } else if (data.result && data.result.success === false) {
                setProgress(1, 1, data.result.error_message || data.result.message || cfg.messages.failed);
                hideProgressSoon();
            } else {
                setProgress(1, 1, (data.result && data.result.message) || 'Richiesta update inviata.');
                hideProgressSoon();
            }
            return data;
        }).catch(function (error) {
            markFailed(siteId, error.message);
            setProgress(1, 1, error.message);
            hideProgressSoon();
        });
    }

    function runDirectUpdates(siteId, row, items, skippedCount) {
        var total = items.length;
        var siteName = row ? row.getAttribute('data-name') || 'Sito' : 'Sito';
        var jobId = 'commander-' + siteId + '-' + Date.now() + '-' + Math.random().toString(16).slice(2);
        var lastData = null;
        var completed = 0;
        skippedCount = parseInt(skippedCount || '0', 10) || 0;

        setProgress(0, total, siteName + ': preparazione aggiornamento');

        return items.reduce(function (promise, item, index) {
            return promise.then(function () {
                if (stopRequested) return null;
                var step = index + 1;
                var label = updateItemLabel(item);
                if (row) setChecking(row, 'Aggiornamento ' + label + ' (' + step + '/' + total + ')');
                setProgress(index, total, siteName + ': ' + label + ' (' + step + '/' + total + ')');
                return postJson(cfg.updatePluginUrl, updateItemFormData(siteId, item, jobId, step, total)).then(function (data) {
                    lastData = data;
                    updateRow(siteId, data.payload || {});
                    if (!data.result || !data.result.success) {
                        var updateError = new Error((data.result && (data.result.error_message || data.result.message)) || 'Aggiornamento fallito.');
                        updateError.rowAlreadyRefreshed = !!(data.payload && data.payload.status && data.payload.status !== 'failed');
                        throw updateError;
                    }
                    completed = step;
                    setProgress(step, total, siteName + ': completato ' + label + ' (' + step + '/' + total + ')');
                    return data;
                });
            });
        }, Promise.resolve()).then(function () {
            if (stopRequested) {
                setProgress(completed, total, cfg.messages.stopped);
                hideProgressSoon();
                return lastData;
            }
            var message = siteName + ': aggiornamento completato.';
            if (lastData && lastData.payload && lastData.payload.status === 'updates') {
                message = siteName + ': operazioni terminate; la verifica forzata rileva ancora aggiornamenti disponibili.';
            }
            if (skippedCount > 0) {
                message += ' MCU escluso dal runner diretto.';
            }
            setProgress(total, total, message);
            hideProgressSoon();
            return lastData;
        }).catch(function (error) {
            if (!error.rowAlreadyRefreshed) {
                markFailed(siteId, error.message);
            } else if (row) {
                clearRowActivity(row);
            }
            setProgress(completed, total, siteName + ': ' + error.message);
            hideProgressSoon();
        });
    }

    function forceSync(siteId) {
        var row = qs('.mc-maint-site-row[data-site-id="' + siteId + '"]');
        if (row) setChecking(row, cfg.messages.syncing);
        return requestJson(cfg.syncUrl, siteId).then(function (data) {
            updateRow(siteId, data.payload || {});
            return data;
        }).catch(function (error) {
            markFailed(siteId, error.message);
        });
    }

    function cancelMasterUpdate(siteId) {
        var row = qs('.mc-maint-site-row[data-site-id="' + siteId + '"]');
        if (row) setChecking(row, cfg.messages.cancelling);
        return requestJson(cfg.cancelMasterUpdateUrl, siteId).then(function (data) {
            updateRow(siteId, data.payload || {});
            return data;
        }).catch(function (error) {
            markFailed(siteId, error.message);
        });
    }

    function startDiagnostics(siteId) {
        var row = qs('.mc-maint-site-row[data-site-id="' + siteId + '"]');
        if (row) setChecking(row, 'Avvio snapshot diagnostico');
        setProgress(0, 1, 'Avvio snapshot diagnostico');
        return requestJson(cfg.startDiagnosticsUrl, siteId).then(function (data) {
            updateRow(siteId, data.payload || {});
            setProgress(1, 1, diagnosticStartMessage(data.result || {}));
            hideProgressSoon();
            return data;
        }).catch(function (error) {
            markFailed(siteId, error.message);
            setProgress(1, 1, error.message);
            hideProgressSoon();
        });
    }

    function syncDiagnostics(siteId) {
        var row = qs('.mc-maint-site-row[data-site-id="' + siteId + '"]');
        if (row) setChecking(row, 'Sincronizzazione snapshot e moduli');
        setProgress(0, 1, 'Sincronizzazione snapshot e moduli');
        return requestJson(cfg.syncDiagnosticsUrl, siteId).then(function (data) {
            updateRow(siteId, data.payload || {});
            setProgress(1, 1, diagnosticSyncMessage(data.result || {}));
            hideProgressSoon();
            return data;
        }).catch(function (error) {
            markFailed(siteId, error.message);
            setProgress(1, 1, error.message);
            hideProgressSoon();
        });
    }

    function frontendScanMessage(data) {
        var scan = data && data.result && data.result.scan ? data.result.scan : {};
        var urls = parseInt(scan.urls_checked || '0', 10) || 0;
        var anomalies = parseInt(scan.anomalies_count || '0', 10) || 0;
        if (urls <= 0 && data && data.result && data.result.results && Array.isArray(data.result.results.pages)) {
            urls = data.result.results.pages.length;
        }
        return 'Scanner frontend completato: ' + urls + ' URL controllati, ' + anomalies + ' anomalie.';
    }

    function aiAnalysisMessage(data) {
        var result = data && data.result ? data.result : {};
        var analysis = result.analysis || {};
        if (result.error === 'gemini_key_missing') {
            return 'Analisi AI saltata: chiave Gemini non configurata.';
        }
        if (result.error) {
            return 'Analisi AI non completata: ' + result.error + '.';
        }
        if (analysis.summary) {
            return analysis.summary;
        }
        return 'Analisi AI completata.';
    }

    function monitorTickMessage(data) {
        var result = data && data.result ? data.result : {};
        var processed = parseInt(result.processed || '0', 10) || 0;
        var parts = [];
        ['heartbeat', 'status', 'updates', 'snapshot', 'frontend', 'ai'].forEach(function (key) {
            var count = parseInt(result[key] || '0', 10) || 0;
            if (count > 0) parts.push(key + ': ' + count);
        });
        var failed = parseInt(result.failed || '0', 10) || 0;
        return cfg.messages.monitorDone + ' Operazioni: ' + processed + (parts.length ? ' (' + parts.join(', ') + ')' : '') + (failed > 0 ? ', fallite: ' + failed : '') + '.';
    }

    function frontendScan(siteId) {
        var row = qs('.mc-maint-site-row[data-site-id="' + siteId + '"]');
        if (row) setChecking(row, 'Scanner frontend esterno');
        setProgress(0, 1, 'Scanner frontend esterno');
        return requestJson(cfg.frontendScanUrl, siteId).then(function (data) {
            if (!data.result || !data.result.success) {
                throw new Error((data.result && data.result.error) || 'Scanner frontend fallito.');
            }
            updateRow(siteId, data.payload || {});
            setProgress(1, 1, frontendScanMessage(data));
            hideProgressSoon();
            return data;
        }).catch(function (error) {
            if (error.message !== 'curl_unavailable') {
                markFailed(siteId, error.message);
            }
            var message = error.message === 'curl_unavailable'
                ? 'Scanner frontend non disponibile: cURL non installato su Commander.'
                : error.message;
            setProgress(1, 1, message);
            hideProgressSoon();
        });
    }

    function aiAnalysis(siteId) {
        var row = qs('.mc-maint-site-row[data-site-id="' + siteId + '"]');
        if (row) setChecking(row, 'Analisi AI sulle prove raccolte');
        setProgress(0, 1, 'Analisi AI sulle prove raccolte');
        return requestJson(cfg.aiAnalysisUrl, siteId).then(function (data) {
            updateRow(siteId, data.payload || {});
            setProgress(1, 1, aiAnalysisMessage(data));
            hideProgressSoon();
            return data;
        }).catch(function (error) {
            setProgress(1, 1, error.message);
            hideProgressSoon();
        });
    }

    function renderDebugLog(siteId, data) {
        var result = data && data.result ? data.result : {};
        var content = result.content || decodeBase64Text(result.content_base64 || '');
        var meta = [];
        if (result.bytes_read) meta.push(result.bytes_read + ' byte');
        if (result.truncated) meta.push('vista tagliata agli ultimi byte disponibili');
        setDebugOutputHtml(siteId, '<div class="mc-maint-debug-result">'
            + '<div class="mc-maint-debug-meta">' + escapeHtml(meta.join(' · ') || 'debug.log') + '</div>'
            + '<textarea class="mc-maint-debug-log" readonly spellcheck="false">' + escapeHtml(content) + '</textarea>'
            + '</div>');
    }

    function renderDebugAi(siteId, data) {
        var output = debugOutput(siteId);
        if (!output) return;
        var result = data && data.result ? data.result : {};
        var response = debugAiResponse(result);
        var summary = debugAiText(response.summary || response.diagnosis || result.message || result.error_message || 'Analisi AI non disponibile.');
        var rawSummary = parseJsonObject(summary);
        if (rawSummary) {
            response = rawSummary;
            summary = debugAiText(response.summary || response.diagnosis || 'Analisi AI completata.');
        }

        var severity = String(response.severity || (result.analysis && result.analysis.severity) || 'info').toLowerCase();
        var confidence = debugAiConfidenceLabel(response.confidence !== undefined ? response.confidence : (result.analysis && result.analysis.confidence));
        var badges = '<span class="mc-maint-debug-ai-badge ' + debugAiSeverityClass(severity) + '">' + escapeHtml(severity || 'info') + '</span>';
        if (confidence) {
            badges += '<span class="mc-maint-debug-ai-badge">' + escapeHtml(confidence) + '</span>';
        }
        if (result.log && result.log.bytes) {
            badges += '<span class="mc-maint-debug-ai-badge">' + escapeHtml(result.log.bytes + ' byte log') + '</span>';
        }

        var sections = '';
        sections += renderDebugAiSection('Plugin/tema coinvolti', response.impacted_components);
        sections += renderDebugAiSection('Problema e soluzione', response.likely_cause);
        sections += renderDebugAiSection('Cosa fare adesso', response.recommended_actions);
        sections += renderDebugAiSection('Prove tecniche', response.relevant_errors || response.evidence_used);
        sections += renderDebugAiSection('Controlli dopo il fix', response.verification_steps);
        if (!sections && result.error_message) {
            sections = renderDebugAiSection('Dettaglio', result.error_message);
        }

        var warning = '';
        if (result.output_truncated) {
            warning = '<div class="mc-maint-debug-ai-warning">La risposta AI ha raggiunto il limite massimo di output. Mostro la diagnosi locale generata dal digest del debug.log; alcune considerazioni AI potrebbero essere parziali.</div>';
        } else if (response._parse_error) {
            warning = '<div class="mc-maint-debug-ai-warning">La risposta AI non era in JSON valido. Ho nascosto il testo grezzo e mostrato solo il riepilogo utilizzabile.</div>';
        }

        setDebugOutputHtml(siteId, '<div class="mc-maint-debug-result">'
            + '<div class="mc-maint-debug-ai-card">'
            + '<div class="mc-maint-debug-ai-head">'
            + '<div><h4 class="mc-maint-debug-ai-title">Analisi AI debug.log</h4><p class="mc-maint-debug-ai-summary">' + escapeHtml(summary) + '</p></div>'
            + '<div class="mc-maint-debug-ai-badges">' + badges + '</div>'
            + '</div>'
            + warning
            + '<div class="mc-maint-debug-ai-grid">' + sections + '</div>'
            + '</div>'
            + '</div>');
    }

    function debugToggle(siteId, enabled) {
        var row = qs('.mc-maint-site-row[data-site-id="' + siteId + '"]');
        if (row) setChecking(row, enabled ? 'Attivazione debug' : 'Disattivazione debug');
        setProgress(0, 1, enabled ? 'Attivazione debug WordPress' : 'Disattivazione debug WordPress');
        return postJson(cfg.debugToggleUrl, debugFormData(siteId, { enabled: enabled ? '1' : '0' })).then(function (data) {
            updateRow(siteId, data.payload || {});
            setProgress(1, 1, (data.result && data.result.message) || 'Stato debug aggiornato.');
            hideProgressSoon();
            return data;
        }).catch(function (error) {
            markFailed(siteId, error.message);
            setProgress(1, 1, error.message);
            hideProgressSoon();
        });
    }

    function debugDelete(siteId) {
        var row = qs('.mc-maint-site-row[data-site-id="' + siteId + '"]');
        if (row) setChecking(row, 'Eliminazione debug.log');
        setProgress(0, 1, 'Eliminazione debug.log');
        return requestJson(cfg.debugDeleteUrl, siteId).then(function (data) {
            clearDebugOutput(siteId);
            updateRow(siteId, data.payload || {});
            setProgress(1, 1, (data.result && data.result.message) || 'debug.log eliminato.');
            hideProgressSoon();
            return data;
        }).catch(function (error) {
            markFailed(siteId, error.message);
            setProgress(1, 1, error.message);
            hideProgressSoon();
        });
    }

    function debugRead(siteId) {
        setProgress(0, 1, 'Lettura debug.log');
        return postJson(cfg.debugLogUrl, debugFormData(siteId, { purpose: 'view', bytes: '524288' })).then(function (data) {
            renderDebugLog(siteId, data);
            setProgress(1, 1, 'debug.log caricato.');
            hideProgressSoon();
            return data;
        }).catch(function (error) {
            setProgress(1, 1, error.message);
            hideProgressSoon();
        });
    }

    function debugAi(siteId, button) {
        var row = qs('.mc-maint-site-row[data-site-id="' + siteId + '"]');
        if (row) setChecking(row, 'Analisi AI debug.log');
        setButtonLoading(button, true, 'Analisi...');
        renderDebugLoading(siteId, 'Analisi AI debug.log in corso', 'Lettura del log e invio manuale al servizio AI configurato.');
        setProgress(0, 1, 'Analisi AI debug.log');
        return requestJson(cfg.debugAiUrl, siteId).then(function (data) {
            updateRow(siteId, data.payload || {});
            renderDebugAi(siteId, data);
            setProgress(1, 1, (data.result && data.result.message) ? 'Analisi AI completata.' : 'Analisi AI terminata.');
            hideProgressSoon();
            return data;
        }).catch(function (error) {
            renderDebugError(siteId, error.message);
            setProgress(1, 1, error.message);
            hideProgressSoon();
        }).then(function (data) {
            setButtonLoading(button, false);
            return data;
        });
    }

    function debugDownload(siteId) {
        var form = document.createElement('form');
        form.method = 'POST';
        form.action = cfg.debugDownloadUrl;
        form.target = '_blank';
        [
            ['csrf_token', cfg.csrfToken || ''],
            ['site_id', siteId]
        ].forEach(function (pair) {
            var input = document.createElement('input');
            input.type = 'hidden';
            input.name = pair[0];
            input.value = pair[1];
            form.appendChild(input);
        });
        document.body.appendChild(form);
        form.submit();
        window.setTimeout(function () {
            form.remove();
        }, 1000);
    }

    function runMonitorTick() {
        if (!cfg.monitorTickUrl) return Promise.resolve();
        var button = qs('#mc-maint-monitor-tick');
        if (button) button.disabled = true;
        stopRequested = false;
        setStopButton(true);
        setProgress(0, 1, cfg.messages.monitoring);
        return postJson(cfg.monitorTickUrl, monitorFormData(10, true, false)).then(function (data) {
            if (stopRequested) {
                setProgress(0, 1, cfg.messages.stopped);
                hideProgressSoon();
                return data;
            }
            var payloads = data.payloads || {};
            Object.keys(payloads).forEach(function (siteId) {
                updateRow(siteId, payloads[siteId]);
            });
            applyStats(data.stats || {});
            setProgress(1, 1, monitorTickMessage(data));
            hideProgressSoon();
            return data;
        }).catch(function (error) {
            setProgress(stopRequested ? 0 : 1, 1, stopRequested ? cfg.messages.stopped : error.message);
            hideProgressSoon();
        }).then(function (data) {
            setStopButton(false);
            if (button) button.disabled = false;
            return data;
        });
    }

    function openModal(site) {
        var modal = qs('#mc-maint-modal');
        var form = qs('#mc-maint-form');
        if (!modal || !form) return;
        form.reset();
        qs('#mc-maint-id').value = site ? site.id : '0';
        qs('#mc-maint-name').value = site ? site.name : '';
        qs('#mc-maint-site-url').value = site ? site.site_url : '';
        qs('#mc-maint-endpoint-url').value = site ? site.endpoint_url : '';
        qs('#mc-maint-secret').value = '';
        qs('#mc-maint-secret').placeholder = site ? 'Lascia vuoto per mantenere quella attuale' : '';
        qs('#mc-maint-dashboard-enabled').checked = site ? site.dashboard_access_enabled === '1' : false;
        qs('#mc-maint-dashboard-url').value = site ? site.dashboard_access_url : '';
        qs('#mc-maint-dashboard-key').value = '';
        qs('#mc-maint-dashboard-key').placeholder = site ? 'Lascia vuoto per mantenere quella attuale' : '';
        qs('#mc-maint-timeout').value = site ? site.timeout : '15';
        qs('#mc-maint-note').value = site ? site.note : '';
        qs('#mc-maint-category').value = site ? site.category : '';
        qs('#mc-maint-server-code').value = site ? site.server_code : '';
        qs('#mc-maint-modal-title').textContent = site ? 'Modifica sito MCU' : 'Aggiungi sito MCU';
        modal.classList.add('open');
    }

    function closeModal() {
        var modal = qs('#mc-maint-modal');
        if (modal) modal.classList.remove('open');
    }

    function selectedSiteIds() {
        return qsa('.mc-maint-row-select:checked').map(function (input) {
            return input.value;
        }).filter(Boolean);
    }

    function sitesWithPendingUpdates() {
        return qsa('.mc-maint-site-row').filter(function (row) {
            return !!qs('.mc-maint-status-dot.is-updates', row)
                && row.getAttribute('aria-busy') !== 'true';
        }).map(function (row) {
            return row.getAttribute('data-site-id');
        }).filter(Boolean);
    }

    function updateSelectionControls() {
        var selected = selectedSiteIds();
        var total = qsa('.mc-maint-row-select').length;
        var selectAll = qs('#mc-maint-select-all');
        var checkSelected = qs('#mc-maint-check-selected');
        var syncSelected = qs('#mc-maint-sync-selected');
        var updateSelected = qs('#mc-maint-update-selected');
        var updatePending = qs('#mc-maint-update-pending');
        if (checkSelected) checkSelected.disabled = groupActionRunning || selected.length === 0;
        if (syncSelected) syncSelected.disabled = groupActionRunning || selected.length === 0;
        if (updateSelected) updateSelected.disabled = groupActionRunning || selected.length === 0;
        if (updatePending) updatePending.disabled = groupActionRunning || sitesWithPendingUpdates().length === 0;
        if (selectAll) {
            selectAll.checked = total > 0 && selected.length === total;
            selectAll.indeterminate = selected.length > 0 && selected.length < total;
        }
    }

    function setGroupButtonsDisabled(disabled) {
        groupActionRunning = disabled;
        ['#mc-maint-check-all', '#mc-maint-check-selected', '#mc-maint-monitor-tick', '#mc-maint-sync-selected', '#mc-maint-update-selected', '#mc-maint-analyze-plugins'].forEach(function (selector) {
            var button = qs(selector);
            var needsSelection = ['#mc-maint-check-selected', '#mc-maint-sync-selected', '#mc-maint-update-selected'].indexOf(selector) !== -1;
            if (button) button.disabled = disabled || (needsSelection && selectedSiteIds().length === 0);
        });
        updateSelectionControls();
    }

    function runSequential(siteIds, worker, doneMessage) {
        var total = siteIds.length;
        var done = 0;
        if (!total) {
            window.alert(cfg.messages.noSelection);
            return Promise.resolve();
        }

        stopRequested = false;
        setGroupButtonsDisabled(true);
        setStopButton(true);
        setProgress(0, total, '0 / ' + total);

        return siteIds.reduce(function (promise, siteId) {
            return promise.then(function () {
                if (stopRequested) return null;
                return worker(siteId).then(function () {
                    done += 1;
                    setProgress(done, total, done + ' / ' + total);
                });
            });
        }, Promise.resolve()).then(function () {
            setStopButton(false);
            setGroupButtonsDisabled(false);
            updateSelectionControls();
            setProgress(done, total, stopRequested ? cfg.messages.stopped : doneMessage);
            updateTrackedJobsProgress();
            hideProgressSoon();
        });
    }

    function runLimitedConcurrency(siteIds, worker, limit, doneMessage) {
        var total = siteIds.length;
        var done = 0;
        var active = 0;
        var nextIndex = 0;
        var settled = false;
        limit = Math.max(1, Math.min(parseInt(limit || '1', 10) || 1, total || 1));

        if (!total) {
            window.alert(cfg.messages.noSelection);
            return Promise.resolve();
        }

        stopRequested = false;
        setGroupButtonsDisabled(true);
        setStopButton(true);
        setProgress(0, total, '0 / ' + total + ' - massimo ' + limit + ' in parallelo');

        return new Promise(function (resolve) {
            function finish() {
                if (settled) return;
                settled = true;
                setStopButton(false);
                setGroupButtonsDisabled(false);
                updateSelectionControls();
                setProgress(done, total, stopRequested ? cfg.messages.stopped : doneMessage);
                updateTrackedJobsProgress();
                hideProgressSoon();
                resolve();
            }

            function pump() {
                if ((stopRequested || nextIndex >= total) && active === 0) {
                    finish();
                    return;
                }

                while (!stopRequested && active < limit && nextIndex < total) {
                    (function (siteId) {
                        active += 1;
                        setProgress(done, total, done + ' / ' + total + ' - ' + active + ' in corso');
                        Promise.resolve()
                            .then(function () {
                                return worker(siteId);
                            })
                            .catch(function (error) {
                                markFailed(siteId, error && error.message ? error.message : cfg.messages.failed);
                            })
                            .then(function () {
                                done += 1;
                                active -= 1;
                                var tail = active > 0 ? ' - ' + active + ' in corso' : '';
                                setProgress(done, total, done + ' / ' + total + tail);
                                pump();
                            });
                    })(siteIds[nextIndex]);
                    nextIndex += 1;
                }
            }

            pump();
        });
    }

    document.addEventListener('DOMContentLoaded', function () {
        ensureButtonTooltips(document);

        var addButton = qs('#mc-maint-open-add');
        if (addButton) {
            addButton.addEventListener('click', function () { openModal(null); });
        }

        ['#mc-maint-close', '#mc-maint-cancel'].forEach(function (selector) {
            var button = qs(selector);
            if (button) button.addEventListener('click', closeModal);
        });

        qsa('.mc-maint-check-site').forEach(function (button) {
            button.addEventListener('click', function () {
                checkSite(button.getAttribute('data-site-id'));
            });
        });

        qsa('.mc-maint-run-update').forEach(function (button) {
            button.addEventListener('click', function () {
                var row = button.closest('.mc-maint-site-row');
                var siteId = row ? row.getAttribute('data-site-id') : '';
                if (siteId && window.confirm(cfg.messages.confirmUpdate)) {
                    runUpdate(siteId);
                }
            });
        });

        qsa('.mc-maint-force-sync').forEach(function (button) {
            button.addEventListener('click', function () {
                var row = button.closest('.mc-maint-site-row');
                var siteId = row ? row.getAttribute('data-site-id') : '';
                if (siteId && window.confirm(cfg.messages.confirmSync)) {
                    forceSync(siteId);
                }
            });
        });

        qsa('.mc-maint-cancel-master-update').forEach(function (button) {
            button.addEventListener('click', function () {
                var row = button.closest('.mc-maint-site-row');
                var siteId = row ? row.getAttribute('data-site-id') : '';
                if (siteId && window.confirm(cfg.messages.confirmCancelMasterUpdate)) {
                    cancelMasterUpdate(siteId);
                }
            });
        });

        document.addEventListener('click', function (event) {
            var securityOpen = event.target.closest('[data-plugin-security-open]');
            var securityAction = event.target.closest('[data-plugin-security-action]');
            if (securityOpen || securityAction) {
                var securityButton = securityOpen || securityAction;
                var securityOwner = securityButton.closest('.mc-maint-site-row, .mc-maint-details-row');
                if (!securityOwner) return;
                var securityId = securityOwner.getAttribute('data-site-id');
                var securityDetails = qs('.mc-maint-details-row[data-site-id="' + securityId + '"]');
                if (securityOpen && securityDetails) {
                    if (securityDetails.hidden) {
                        var securityToggle = qs('.mc-maint-details-toggle', securityOwner);
                        if (securityToggle) securityToggle.click();
                        else securityDetails.hidden = false;
                    }
                    var tab = qs('.mc-maint-tab-button[data-maint-tab="plugin-security"]', securityDetails);
                    if (tab) activateDetailsTab(tab);
                    return;
                }
                var securityOperation = securityAction.getAttribute('data-plugin-security-action');
                var pluginName = securityAction.getAttribute('data-plugin-name') || '';
                if (securityOperation === 'whitelist' && !window.confirm('Aggiungere ' + pluginName + ' alla whitelist condivisa tra i siti, valida anche per le versioni successive dello stesso percorso?')) return;
                if (securityOperation === 'forget' && !window.confirm('Rimuovere la valutazione di ' + pluginName + ' dal registro condiviso? Sara rivalutato soltanto alla prossima analisi su comando.')) return;
                if (securityOperation === 'remove') {
                    var siteRow = qs('.mc-maint-site-row[data-site-id="' + securityId + '"]');
                    var siteLabel = siteRow ? siteRow.getAttribute('data-name') + ' (' + siteRow.getAttribute('data-site-url') + ')' : securityId;
                    if (!window.confirm('Eliminare definitivamente i file di ' + pluginName + ' [' + securityAction.getAttribute('data-plugin-file') + '] dal sito ' + siteLabel + '? Il plugin verra disattivato; dati e opzioni restano. L’operazione puo modificare il funzionamento del sito.')) return;
                }
                pluginSecurityAction(securityId, securityOperation, securityAction, false);
                return;
            }
            var tabButton = event.target.closest('button.mc-maint-tab-button');
            if (tabButton) {
                activateDetailsTab(tabButton);
                return;
            }

            var startButton = event.target.closest('button.mc-maint-start-diagnostics');
            if (startButton) {
                var startSiteId = siteIdFromButton(startButton);
                if (startSiteId && window.confirm(cfg.messages.confirmStartDiagnostics)) {
                    startDiagnostics(startSiteId);
                }
                return;
            }

            var syncButton = event.target.closest('button.mc-maint-sync-diagnostics');
            if (syncButton) {
                var syncSiteId = siteIdFromButton(syncButton);
                if (syncSiteId && window.confirm(cfg.messages.confirmSyncDiagnostics)) {
                    syncDiagnostics(syncSiteId);
                }
                return;
            }

            var frontendButton = event.target.closest('button.mc-maint-frontend-scan');
            if (frontendButton) {
                var frontendSiteId = siteIdFromButton(frontendButton);
                if (frontendSiteId && window.confirm(cfg.messages.confirmFrontendScan)) {
                    frontendScan(frontendSiteId);
                }
                return;
            }

            var aiButton = event.target.closest('button.mc-maint-ai-analysis');
            if (aiButton) {
                var aiSiteId = siteIdFromButton(aiButton);
                if (aiSiteId && window.confirm(cfg.messages.confirmAiAnalysis)) {
                    aiAnalysis(aiSiteId);
                }
                return;
            }

            var debugToggleButton = event.target.closest('button.mc-maint-debug-toggle');
            if (debugToggleButton) {
                var debugToggleSiteId = siteIdFromButton(debugToggleButton);
                var enabled = debugToggleButton.getAttribute('data-enabled') === '1';
                var message = enabled ? cfg.messages.confirmDebugEnable : cfg.messages.confirmDebugDisable;
                if (debugToggleSiteId && window.confirm(message)) {
                    debugToggle(debugToggleSiteId, enabled);
                }
                return;
            }

            var debugReadButton = event.target.closest('button.mc-maint-debug-read');
            if (debugReadButton) {
                var debugReadSiteId = siteIdFromButton(debugReadButton);
                if (debugReadSiteId) {
                    debugRead(debugReadSiteId);
                }
                return;
            }

            var debugDownloadButton = event.target.closest('button.mc-maint-debug-download');
            if (debugDownloadButton) {
                var debugDownloadSiteId = siteIdFromButton(debugDownloadButton);
                if (debugDownloadSiteId) {
                    debugDownload(debugDownloadSiteId);
                }
                return;
            }

            var debugAiButton = event.target.closest('button.mc-maint-debug-ai');
            if (debugAiButton) {
                var debugAiSiteId = siteIdFromButton(debugAiButton);
                if (debugAiSiteId && window.confirm(cfg.messages.confirmDebugAi)) {
                    debugAi(debugAiSiteId, debugAiButton);
                }
                return;
            }

            var debugDeleteButton = event.target.closest('button.mc-maint-debug-delete');
            if (debugDeleteButton) {
                var debugDeleteSiteId = siteIdFromButton(debugDeleteButton);
                if (debugDeleteSiteId && window.confirm(cfg.messages.confirmDebugDelete)) {
                    debugDelete(debugDeleteSiteId);
                }
            }
        });

        qsa('.mc-maint-details-toggle').forEach(function (button) {
            button.addEventListener('click', function () {
                var row = button.closest('.mc-maint-site-row');
                var details = row ? qs('.mc-maint-details-row[data-site-id="' + row.getAttribute('data-site-id') + '"]') : null;
                if (!details) return;
                var shouldOpen = details.hidden;
                qsa('.mc-maint-details-row').forEach(function (openRow) {
                    if (openRow !== details) {
                        openRow.hidden = true;
                    }
                });
                qsa('.mc-maint-details-toggle').forEach(function (toggle) {
                    if (toggle !== button) {
                        toggle.setAttribute('aria-expanded', 'false');
                    }
                });
                details.hidden = !shouldOpen;
                button.setAttribute('aria-expanded', shouldOpen ? 'true' : 'false');
            });
        });

        qsa('.mc-maint-edit-site').forEach(function (button) {
            button.addEventListener('click', function () {
                var row = button.closest('.mc-maint-site-row');
                if (!row) return;
                openModal({
                    id: row.getAttribute('data-site-id') || '0',
                    name: row.getAttribute('data-name') || '',
                    category: row.getAttribute('data-category') || '',
                    server_code: row.getAttribute('data-server-code') || '',
                    site_url: row.getAttribute('data-site-url') || '',
                    endpoint_url: row.getAttribute('data-endpoint-url') || '',
                    dashboard_access_url: row.getAttribute('data-dashboard-access-url') || '',
                    dashboard_access_enabled: row.getAttribute('data-dashboard-access-enabled') || '0',
                    note: row.getAttribute('data-note') || '',
                    timeout: row.getAttribute('data-timeout') || '15'
                });
            });
        });

        document.addEventListener('change', function (event) {
            var toggle = event.target;
            if (!toggle || !toggle.classList.contains('mc-maint-update-exclusion-toggle')) return;
            var details = toggle.closest('.mc-maint-details-row');
            var siteId = details ? details.getAttribute('data-site-id') || '' : '';
            var row = siteId ? qs('.mc-maint-site-row[data-site-id="' + siteId + '"]') : null;
            if (!row) return;

            var data = formData(siteId);
            data.append('type', toggle.getAttribute('data-type') || 'plugin');
            data.append('identifier', toggle.getAttribute('data-identifier') || '');
            data.append('file', toggle.getAttribute('data-file') || '');
            data.append('slug', toggle.getAttribute('data-slug') || '');
            data.append('name', toggle.getAttribute('data-name') || '');
            data.append('excluded', toggle.checked ? '1' : '0');
            toggle.disabled = true;
            setExclusionToggleError(toggle, '');
            postJson(cfg.updateExclusionUrl, data).then(function (payload) {
                if (payload && payload.payload) {
                    updateRow(siteId, payload.payload);
                }
            }).catch(function (error) {
                toggle.checked = !toggle.checked;
                setExclusionToggleError(toggle, error.message);
                markFailed(siteId, error.message);
            }).then(function () {
                toggle.disabled = false;
            });
        });

        qsa('.mc-maint-delete-form').forEach(function (form) {
            form.addEventListener('submit', function (event) {
                var localDeleteInput = qs('input[name="force_local_delete"]', form);
                var localDelete = localDeleteInput && localDeleteInput.value === '1';
                var message = localDelete ? cfg.messages.confirmLocalDelete : cfg.messages.confirmDelete;
                if (!window.confirm(message)) {
                    event.preventDefault();
                }
            });
        });

        var checkAll = qs('#mc-maint-check-all');
        var analyzePlugins = qs('#mc-maint-analyze-plugins');
        if (analyzePlugins) {
            analyzePlugins.addEventListener('click', function () {
                var ids = selectedSiteIds();
                if (!ids.length) ids = qsa('.mc-maint-site-row').map(function (row) { return row.getAttribute('data-site-id'); });
                runSequential(ids, function (id) { return pluginSecurityAction(id, 'analyze', null, true); }, 'Analisi plugin elaborate. Controlla segnalazioni ed eventuali errori nelle righe.');
            });
        }
        var checkSelected = qs('#mc-maint-check-selected');
        var monitorTick = qs('#mc-maint-monitor-tick');
        var syncSelected = qs('#mc-maint-sync-selected');
        var updateSelected = qs('#mc-maint-update-selected');
        var selectAll = qs('#mc-maint-select-all');
        var updatePending = qs('#mc-maint-update-pending');
        var stop = qs('#mc-maint-stop-checks');

        qsa('.mc-maint-row-select').forEach(function (input) {
            input.addEventListener('change', updateSelectionControls);
        });

        if (selectAll) {
            selectAll.addEventListener('change', function () {
                qsa('.mc-maint-row-select').forEach(function (input) {
                    input.checked = selectAll.checked;
                });
                updateSelectionControls();
            });
        }

        if (checkSelected) {
            checkSelected.addEventListener('click', function () {
                runSequential(selectedSiteIds(), checkSite, cfg.messages.selectedChecksDone);
            });
        }

        if (monitorTick) {
            monitorTick.addEventListener('click', runMonitorTick);
        }

        if (syncSelected) {
            syncSelected.addEventListener('click', function () {
                var ids = selectedSiteIds();
                if (!ids.length) {
                    window.alert(cfg.messages.noSelection);
                    return;
                }
                if (window.confirm(cfg.messages.confirmSync)) {
                    runLimitedConcurrency(ids, forceSync, cfg.syncConcurrency || 3, cfg.messages.selectedSyncDone);
                }
            });
        }

        if (updateSelected) {
            updateSelected.addEventListener('click', function () {
                var ids = selectedSiteIds();
                if (!ids.length) {
                    window.alert(cfg.messages.noSelection);
                    return;
                }
                if (window.confirm(cfg.messages.confirmUpdate)) {
                    runSequential(ids, runUpdate, cfg.messages.selectedUpdatesDone);
                }
            });
        }

        if (updatePending) {
            updatePending.addEventListener('click', function () {
                if (groupActionRunning) return;
                var ids = sitesWithPendingUpdates();
                if (!ids.length) {
                    window.alert(cfg.messages.noPendingUpdates);
                    return;
                }
                if (window.confirm(cfg.messages.confirmPendingUpdates.replace('{count}', ids.length))) {
                    runSequential(ids, function (siteId) {
                        // Rows can change while earlier sites are being updated.
                        return sitesWithPendingUpdates().indexOf(siteId) !== -1
                            ? runUpdate(siteId) : Promise.resolve(null);
                    }, cfg.messages.pendingUpdatesDone);
                }
            });
        }

        if (checkAll) {
            checkAll.addEventListener('click', function () {
                var ids = qsa('.mc-maint-check-site').map(function (button) {
                    return button.getAttribute('data-site-id');
                }).filter(Boolean);
                runSequential(ids, checkSite, cfg.messages.allDone);
            });
        }

        if (stop) {
            stop.addEventListener('click', function () {
                stopRequested = true;
                stop.disabled = true;
            });
        }

        updateSelectionControls();
        resumeTrackedUpdateJobs();
        refreshStats();
        refreshProblemRowsFromCommander();
        window.setInterval(refreshStats, 5000);
        window.setInterval(refreshProblemRowsFromCommander, 5000);
    });
}());
</script>
