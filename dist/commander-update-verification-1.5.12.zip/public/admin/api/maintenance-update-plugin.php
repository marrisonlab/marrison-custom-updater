<?php

require_once dirname(__DIR__, 3) . '/app/bootstrap.php';

use App\Controllers\AdminMaintenanceController;
use App\Models\MaintenanceSite;
use App\Services\MaintenanceHttpClient;

require_admin_login(true);

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    json_error('Metodo non consentito', 405);
}

if (!verify_csrf($_POST['csrf_token'] ?? null)) {
    json_error('Token di sicurezza non valido', 403);
}

$siteId = (int) ($_POST['site_id'] ?? 0);
$site = MaintenanceSite::find($siteId);
if (!$site) {
    json_error('Sito non trovato', 404);
}

$updateType = (string) ($_POST['update_type'] ?? 'plugin');
$item = [
    'file' => (string) ($_POST['plugin_file'] ?? ''),
    'slug' => (string) ($_POST['slug'] ?? ''),
    'name' => (string) ($_POST['name'] ?? ''),
    'type' => (string) ($_POST['type'] ?? ''),
    'current_version' => (string) ($_POST['current_version'] ?? ''),
    'new_version' => (string) ($_POST['new_version'] ?? ''),
    'package' => (string) ($_POST['package'] ?? ''),
];
$jobId = (string) ($_POST['job_id'] ?? '');
$step = max(1, (int) ($_POST['step'] ?? 1));
$total = max($step, (int) ($_POST['total'] ?? $step));

$result = MaintenanceHttpClient::requestUpdateItem($site, $updateType, $item, $jobId, $step, $total);
MaintenanceSite::storeActionResult($siteId, $result, $updateType === 'theme' ? 'update_theme' : 'update_plugin');

$site = MaintenanceSite::find($siteId) ?: $site;
$checkResult = MaintenanceHttpClient::verifyUpdates($site);
MaintenanceSite::storeCheckResult($siteId, $checkResult);
if (($checkResult['status'] ?? '') === 'failed') {
    $result['success'] = false;
    $result['status'] = 'failed';
    $result['error_type'] = (string) ($checkResult['error_type'] ?? 'update_verification_failed');
    $result['error_message'] = (string) ($checkResult['error_message'] ?? 'Verifica finale aggiornamento non riuscita.');
}

$site = MaintenanceSite::find($siteId);

json_response([
    'success' => true,
    'data' => [
        'payload' => $site ? AdminMaintenanceController::sitePayload($site) : [],
        'result' => $result,
        'check_result' => $checkResult,
    ],
]);
