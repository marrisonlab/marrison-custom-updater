<?php

require_once dirname(__DIR__, 3) . '/app/bootstrap.php';

use App\Controllers\AdminMaintenanceController;
use App\Models\MaintenanceSite;
use App\Services\MaintenanceHttpClient;

require_admin_login(true);

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    json_error('Metodo non consentito', 405);
}

if (!verify_csrf($_POST['csrf_token'] ?? null)) {
    json_error('Token di sicurezza non valido', 403);
}

$siteId = (int) ($_POST['site_id'] ?? 0);
$site = MaintenanceSite::find($siteId);
if (!$site) {
    json_error('Sito non trovato', 404);
}

$syncResult = MaintenanceHttpClient::verifyUpdates($site);
MaintenanceSite::storeActionResult($siteId, $syncResult, 'force_sync');
MaintenanceSite::storeCheckResult($siteId, $syncResult);
$site = MaintenanceSite::find($siteId);

json_response([
    'success' => true,
    'data' => [
        'payload' => $site ? AdminMaintenanceController::sitePayload($site) : [],
        'result' => $syncResult,
    ],
]);
