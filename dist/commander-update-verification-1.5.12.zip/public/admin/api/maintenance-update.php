<?php

require_once dirname(__DIR__, 3) . '/app/bootstrap.php';

use App\Controllers\AdminMaintenanceController;
use App\Models\MaintenanceSite;
use App\Models\MaintenanceUpdateJob;
use App\Services\MaintenanceHttpClient;

require_admin_login(true);

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    json_error('Metodo non consentito', 405);
}

if (!verify_csrf($_POST['csrf_token'] ?? null)) {
    json_error('Token di sicurezza non valido', 403);
}

$siteId = (int) ($_POST['site_id'] ?? 0);
$site = MaintenanceSite::find($siteId);
if (!$site) {
    json_error('Sito non trovato', 404);
}

$result = MaintenanceHttpClient::requestUpdate($site);
MaintenanceSite::storeActionResult($siteId, $result, 'update_all');
$job = MaintenanceUpdateJob::upsertFromAction($siteId, $result, 'update_all');

$checkResult = null;
if ($job && MaintenanceUpdateJob::isTerminal((string) ($job['status'] ?? ''))) {
    $site = MaintenanceSite::find($siteId) ?: $site;
    $checkResult = MaintenanceHttpClient::verifyUpdates($site);
    if (!empty($checkResult['success']) || (string) ($checkResult['status'] ?? '') !== 'failed') {
        MaintenanceSite::storeCheckResult($siteId, $checkResult);
        $statusData = is_array($checkResult['response_data'] ?? null) ? $checkResult['response_data'] : [];
        $job = MaintenanceUpdateJob::syncFromStatus(
            $siteId,
            $statusData,
            'poll',
            (string) ($job['remote_job_id'] ?? '')
        ) ?: $job;
        $job = MaintenanceUpdateJob::failIfVerifiedUpdatesRemain($siteId, $job, $statusData, $site) ?: $job;
    } else {
        $job = MaintenanceUpdateJob::failTerminalVerification(
            $siteId,
            $job,
            (string) ($checkResult['error_type'] ?? 'status_check_failed'),
            (string) ($checkResult['error_message'] ?? 'Verifica finale job non riuscita.')
        ) ?: $job;
    }
} elseif (!$job && empty($result['success'])) {
    $site = MaintenanceSite::find($siteId) ?: $site;
    $checkResult = MaintenanceHttpClient::check($site);
    MaintenanceSite::storeCheckResult($siteId, $checkResult);
    $job = MaintenanceUpdateJob::syncFromStatus(
        $siteId,
        is_array($checkResult['response_data'] ?? null) ? $checkResult['response_data'] : [],
        'poll'
    );
}

$site = MaintenanceSite::find($siteId);

json_response([
    'success' => true,
    'data' => [
        'payload' => $site ? AdminMaintenanceController::sitePayload($site) : [],
        'result' => $result,
        'job' => MaintenanceUpdateJob::publicPayload($job),
        'check_result' => $checkResult,
    ],
]);
