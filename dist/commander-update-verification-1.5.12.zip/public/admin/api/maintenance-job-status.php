<?php

require_once dirname(__DIR__, 3) . '/app/bootstrap.php';

use App\Controllers\AdminMaintenanceController;
use App\Models\MaintenanceSite;
use App\Models\MaintenanceUpdateJob;
use App\Services\MaintenanceHttpClient;

require_admin_login(true);

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    json_error('Metodo non consentito', 405);
}

if (!verify_csrf($_POST['csrf_token'] ?? null)) {
    json_error('Token di sicurezza non valido', 403);
}

$siteId = (int) ($_POST['site_id'] ?? 0);
$remoteJobId = trim((string) ($_POST['job_id'] ?? ''));
$site = MaintenanceSite::find($siteId);
if (!$site) {
    json_error('Sito non trovato', 404);
}

$job = $remoteJobId !== ''
    ? MaintenanceUpdateJob::findByRemoteJobId($siteId, $remoteJobId)
    : MaintenanceUpdateJob::latestActiveForSite($siteId);

if (!$job) {
    json_response([
        'success' => true,
        'data' => [
            'payload' => AdminMaintenanceController::sitePayload($site),
            'job' => [],
            'result' => null,
        ],
    ]);
}

if (MaintenanceUpdateJob::isTerminal((string) ($job['status'] ?? ''))) {
    if (in_array((string) ($job['status'] ?? ''), ['completed', 'skipped'], true)) {
        $checkResult = MaintenanceHttpClient::verifyUpdates($site);
        if (!empty($checkResult['success']) || (string) ($checkResult['status'] ?? '') !== 'failed') {
            MaintenanceSite::storeCheckResult($siteId, $checkResult);
            $statusData = is_array($checkResult['response_data'] ?? null) ? $checkResult['response_data'] : [];
            $job = MaintenanceUpdateJob::failIfVerifiedUpdatesRemain($siteId, $job, $statusData) ?: $job;
            $site = MaintenanceSite::find($siteId) ?: $site;
        } else {
            $job = MaintenanceUpdateJob::failTerminalVerification(
                $siteId,
                $job,
                (string) ($checkResult['error_type'] ?? 'status_check_failed'),
                (string) ($checkResult['error_message'] ?? 'Verifica finale job non riuscita.')
            ) ?: $job;
        }
    }

    json_response([
        'success' => true,
        'data' => [
            'payload' => AdminMaintenanceController::sitePayload($site),
            'job' => MaintenanceUpdateJob::publicPayload($job),
            'result' => $checkResult ?? null,
        ],
    ]);
}

$checkResult = MaintenanceHttpClient::check($site);
$statusData = is_array($checkResult['response_data'] ?? null) ? $checkResult['response_data'] : [];
// Read terminal job evidence even if the update metadata is incomplete.
if (!empty($statusData['mcu_master_update_status']['job_id'])) {
    $job = MaintenanceUpdateJob::syncFromStatus(
        $siteId,
        $statusData,
        'poll',
        (string) ($job['remote_job_id'] ?? '')
    ) ?: $job;
}
if (in_array((string) ($job['status'] ?? ''), ['completed', 'skipped'], true)) {
    $checkResult = MaintenanceHttpClient::verifyUpdates($site);
    $statusData = is_array($checkResult['response_data'] ?? null) ? $checkResult['response_data'] : [];
}
MaintenanceSite::storeCheckResult($siteId, $checkResult);
if (($checkResult['status'] ?? '') !== 'failed') {
    $job = MaintenanceUpdateJob::failIfVerifiedUpdatesRemain($siteId, $job, $statusData) ?: $job;
} else {
    $job = MaintenanceUpdateJob::failTerminalVerification(
        $siteId,
        $job,
        (string) ($checkResult['error_type'] ?? 'status_check_failed'),
        (string) ($checkResult['error_message'] ?? 'Verifica stato job non riuscita.')
    ) ?: $job;
}

$site = MaintenanceSite::find($siteId) ?: $site;

json_response([
    'success' => true,
    'data' => [
        'payload' => AdminMaintenanceController::sitePayload($site),
        'job' => MaintenanceUpdateJob::publicPayload($job),
        'result' => $checkResult,
    ],
]);
