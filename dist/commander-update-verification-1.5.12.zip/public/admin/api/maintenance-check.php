<?php

require_once dirname(__DIR__, 3) . '/app/bootstrap.php';

use App\Controllers\AdminMaintenanceController;
use App\Models\MaintenanceSite;
use App\Services\MaintenanceExternalProbeService;
use App\Services\MaintenanceHttpClient;

require_admin_login(true);

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    json_error('Metodo non consentito', 405);
}

if (!verify_csrf($_POST['csrf_token'] ?? null)) {
    json_error('Token di sicurezza non valido', 403);
}

$siteId = (int) ($_POST['site_id'] ?? 0);
$site = MaintenanceSite::find($siteId);
if (!$site) {
    json_error('Sito non trovato', 404);
}

$result = MaintenanceHttpClient::verifyUpdates($site);
if (($result['error_type'] ?? '') === 'timeout') {
    try {
        $probe = MaintenanceExternalProbeService::probe($site, 'home', '', 0);
        $probeData = is_array($probe['data']['probe'] ?? null) ? $probe['data']['probe'] : [];
        if ($probeData) {
            $result['diagnostics']['external_probe_home'] = [
                'probed_at' => (string) ($probeData['probed_at'] ?? ''),
                'http_code' => (int) ($probeData['http_code'] ?? 0),
                'total_ms' => (int) ($probeData['total_ms'] ?? 0),
                'ttfb_ms' => (int) ($probeData['ttfb_ms'] ?? 0),
                'error_type' => (string) ($probeData['error_type'] ?? ''),
                'error_message' => (string) ($probeData['error_message'] ?? ''),
            ];
            $result['error_message'] = trim((string) ($result['error_message'] ?? ''))
                . ' ' . maintenance_timeout_probe_summary($probeData);
        }
    } catch (\Throwable $e) {
        $result['diagnostics']['external_probe_home_error'] = $e->getMessage();
    }
}
MaintenanceSite::storeCheckResult($siteId, $result);
$site = MaintenanceSite::find($siteId);

json_response([
    'success' => true,
    'data' => $site ? AdminMaintenanceController::sitePayload($site) : [],
]);

function maintenance_timeout_probe_summary(array $probe): string
{
    $errorType = trim((string) ($probe['error_type'] ?? ''));
    $errorMessage = trim((string) ($probe['error_message'] ?? ''));
    if ($errorType !== '') {
        return 'Probe pubblico homepage fallito: ' . ($errorMessage !== '' ? $errorMessage : $errorType) . '.';
    }

    $httpCode = (int) ($probe['http_code'] ?? 0);
    $totalMs = (int) ($probe['total_ms'] ?? 0);
    if ($httpCode > 0) {
        return 'Probe pubblico homepage: HTTP ' . $httpCode . ' in ' . $totalMs . ' ms.';
    }

    return 'Probe pubblico homepage senza risposta HTTP.';
}
