# Verifica aggiornamenti MCU / Commander

MCU 9.8.24 e Commander 1.5.12 aggiungono due pianificazioni indipendenti con
orario iniziale 03:00 Europe/Rome. La verifica cerca gli aggiornamenti con una
sincronizzazione forzata; non installa plugin, temi o WordPress.

## Installazione

1. Conservare una copia dei file precedenti e distribuire MCU 9.8.24 sui siti.
2. Applicare la patch Commander 1.5.12 mantenendo i percorsi del pacchetto.
   Nessuna migrazione database e nessuna modifica alle chiavi dei client.
3. In Commander, Impostazioni > Verifica programmata siti MCU, abilitare il
   controllo e scegliere l'orario. Salvare aggiorna le scadenze dei siti.
4. Sul server Commander pianificare ogni cinque minuti, dalla directory
   dell'applicazione: `php bin/maintenance-monitor.php --limit=30`.
   Il percorso dell'eseguibile PHP dipende dall'hosting. Conservare stdout/stderr
   del comando per verificare esecuzioni e fallimenti. Il limite e per operazioni;
   la flotta viene smaltita su piu esecuzioni. Il runner usa un lock locale.
5. In MCU, Impostazioni > Generale > Verifica aggiornamenti, configurare la
   verifica locale. Per eseguirla anche senza visite, aggiungere nell'hosting
   una chiamata a `wp-cron.php` ogni cinque minuti (o il runner cron WordPress
   equivalente gia usato dall'hosting). La sola attivazione in MCU non crea
   un cron del sistema operativo. La scansione diretta da Commander funziona
   anche quando questo cron locale non e presente.

Le due pianificazioni possono coesistere. Il lock MCU impedisce due sync
contemporanee; il controllo che incontra un lock o un errore riprova dopo
15 minuti. Le richieste manuali di Verifica e Sincronizza usano lo stesso
percorso di sincronizzazione forzata; il polling del progresso rimane leggero
finche il job e attivo. Alla conclusione viene eseguita la verifica forzata.

## Verifica dopo il deployment

- Verificare salvataggio e persistenza dell'orario nei due pannelli. In MCU
  controllare il prossimo evento, l'ultimo tentativo e l'ultimo successo;
  in Commander controllare data e contatori dell'ultima esecuzione del runner.
- Su un sito con aggiornamenti noti usare Verifica: deve trovare gli stessi
  aggiornamenti di Sincronizza senza un passaggio manuale aggiuntivo.
- Aggiornare i plugin. La chiusura deve mostrare le versioni installate corrette
  e zero aggiornamenti residui oppure un errore esplicito con i residui.
- Verificare il giro notturno su un sito senza visite usando il cron del server.
  Un errore di rete/repository deve essere visibile e ritentato dopo 15 minuti.

## Validazione locale

- `php tests/maintenance-verification-regression.php` (Commander)
- `php tests/update-verification-regression.php` (MCU)

Le fixture simulano HTTP e database: non provano l'esecuzione del cron
dell'hosting, il funzionamento dei provider remoti o l'installazione su siti live.
