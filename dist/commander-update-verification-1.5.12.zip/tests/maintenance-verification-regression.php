<?php
/** Local HTTP/database doubles; no real requests, credentials or database. */
namespace App\Models {
    class Settings {
        public static array $values = [];
        public static function get($key, $default = null) { return self::$values[$key] ?? $default; }
        public static function getMcuRepositoryConfig() { return []; }
    }
    class Database {
        public static function connection() {
            return new class {
                public function query($sql) { return $this->prepare($sql); }
                public function prepare($sql) {
                    return new class($sql) {
                        public function __construct(private string $sql) {}
                        public function execute($params = []) { $GLOBALS['sql'][] = [$this->sql, $params]; return true; }
                        public function fetch($mode = null) { return ['maintenance_site_id' => 1]; }
                        public function fetchAll($mode = null) { return str_contains($this->sql, 'm.updates_due_at') ? [1] : []; }
                    };
                }
            };
        }
    }
    class MaintenanceSite {
        public static function find($id) { return ['id' => 1, 'endpoint_url' => 'https://fixture.invalid/wp-json/marrison-maintenance/v1/status', 'secret_encrypted' => 'fixture']; }
        public static function all() { return [self::find(1)]; }
        public static function storeCheckResult($id, $result) { $GLOBALS['stored'][] = $result; }
        public static function storeActionResult($id, $result, $type = '') {}
    }
    class MaintenanceSignal { public static function activeForSite($id) { return []; } }
}
namespace App\Services {
    class MaintenanceSecretVault { public static function decrypt($value) { return $value; } }
    class MaintenanceDebugLogger { public static function log($event, $data) {} }
    class MaintenanceSnapshotSyncService { public static function syncManifestFromStatus($site, $data) {} }
    class MaintenanceSignalService { public static function analyzeSite($id) { return ['signals' => []]; } }
    function function_exists($name) { return $name === 'curl_init' || \function_exists($name); }
    function curl_init($url) { return (object) ['url' => $url, 'options' => []]; }
    function curl_setopt_array($handle, $options) { $handle->options = $options; }
    function curl_exec($handle) {
        $body = json_decode($handle->options[CURLOPT_POSTFIELDS], true);
        $GLOBALS['requests'][] = $body;
        if (($body['operation'] ?? '') === 'force_sync') {
            if ($GLOBALS['syncFails']) { return json_encode(['success' => false, 'error_code' => 'repository_unavailable', 'message' => 'Repository non raggiungibile.']); }
            $GLOBALS['cached'] = $GLOBALS['available'];
            return json_encode(['success' => true, 'data' => ['message' => 'Sincronizzazione completata.']]);
        }
        return json_encode(['success' => true, 'plugin_updates' => array_fill(0, $GLOBALS['cached'], ['file' => 'fixture/main.php', 'new_version' => '2.0']),
            'theme_updates' => [], 'translation_updates' => [], 'updates_may_be_stale' => $GLOBALS['stale'],
            'updates_available_count' => $GLOBALS['cached']]);
    }
    function curl_getinfo($handle, $key) { return match($key) { CURLINFO_RESPONSE_CODE => 200, CURLINFO_EFFECTIVE_URL => $handle->url, default => 0 }; }
    function curl_close($handle) {}
    function curl_error($handle) { return ''; }
}
namespace {
    use App\Models\Settings;
    use App\Models\MaintenanceSite;
    use App\Models\MaintenanceMonitorState;
    use App\Services\MaintenanceHttpClient;
    use App\Services\MaintenanceMonitorService;
    use App\Services\MaintenanceVerificationSchedule;
    date_default_timezone_set('Europe/Rome');
    set_error_handler(static function($severity, $message, $file, $line) { throw new \ErrorException($message, 0, $severity, $file, $line); });
    $names = ['CURLINFO_EFFECTIVE_URL', 'CURLINFO_HEADER_SIZE', 'CURLINFO_REDIRECT_COUNT', 'CURLINFO_RESPONSE_CODE', 'CURLOPT_CONNECTTIMEOUT',
        'CURLOPT_FOLLOWLOCATION', 'CURLOPT_HEADER', 'CURLOPT_HTTPHEADER', 'CURLOPT_MAXREDIRS', 'CURLOPT_POST', 'CURLOPT_POSTFIELDS',
        'CURLOPT_RETURNTRANSFER', 'CURLOPT_SSL_VERIFYHOST', 'CURLOPT_SSL_VERIFYPEER', 'CURLOPT_TIMEOUT'];
    foreach ($names as $i => $name) { if (!defined($name)) { define($name, 10000 + $i); } }
    function config($key, $default = null) { return $default; }
    function now_str() { return date('Y-m-d H:i:s'); }
    foreach (['Services/MaintenanceDiagnosticSanitizer', 'Services/MaintenanceHttpClient', 'Services/MaintenanceVerificationSchedule', 'Models/MaintenanceMonitorState', 'Services/MaintenanceMonitorService'] as $file) {
        require __DIR__ . '/../app/' . $file . '.php';
    }
    $requests = []; $stored = []; $sql = []; $available = 3; $cached = 0; $syncFails = false; $stale = false; $checks = 0;
    function check($condition, $label) { if (!$condition) throw new \RuntimeException($label); $GLOBALS['checks']++; }
    $site = MaintenanceSite::find(1);
    check(MaintenanceHttpClient::check($site)['status'] === 'ok', 'Fixture reproduces previous cached green');
    $verified = MaintenanceHttpClient::verifyUpdates($site);
    check($verified['status'] === 'updates', 'Verify discovers 3 updates through forced sync');
    check(!empty($verified['success']), 'Successful verification exposes success for action consumers');
    check($requests[count($requests) - 2]['operation'] === 'force_sync', 'Force sync precedes status');
    $available = 1; $cached = 0;
    check(MaintenanceHttpClient::verifyUpdates($site)['status'] === 'updates', 'A remaining update after installation cannot turn green');
    $available = 0;
    check(MaintenanceHttpClient::verifyUpdates($site)['status'] === 'ok', 'Green only after actual fresh zero');
    $syncFails = true;
    $before = count($requests);
    $result = MaintenanceHttpClient::verifyUpdates($site);
    check($result['status'] === 'failed' && !$result['success'], 'Failed forced sync cannot become successful verification');
    check(count($requests) === $before + 1, 'Failed sync is not overwritten by a cached status');
    $syncFails = false; $stale = true;
    check(MaintenanceHttpClient::check($site)['status'] === 'failed', 'Stale or cleared metadata is never green');
    $stale = false;
    check(MaintenanceVerificationSchedule::configuration()['time'] === '03:00', 'Default daily time');
    foreach (['00:00', '03:00', '23:59'] as $time) check(MaintenanceVerificationSchedule::validTime($time), 'Valid time');
    foreach (['24:00', '3:00', '03:70', 'bad'] as $time) check(!MaintenanceVerificationSchedule::validTime($time), 'Rejects invalid time');
    foreach (['2026-03-28 12:00', '2026-03-29 12:00', '2026-10-24 12:00', '2026-10-25 12:00'] as $date) {
        $now = (new \DateTimeImmutable($date, new \DateTimeZone('Europe/Rome')))->getTimestamp();
        $next = new \DateTimeImmutable(MaintenanceVerificationSchedule::dueAt(1, $now, true));
        check($next->getTimestamp() > $now, 'Future daily event across DST');
        check($next->format('H:i') >= '03:00' && $next->format('H:i') <= '03:15', 'Maintains 03:00 window across DST');
    }
    Settings::$values['maintenance_verification_time'] = '05:40';
    check(str_contains(MaintenanceVerificationSchedule::dueAt(1), '05:'), 'Custom configured time');
    $syncFails = true;
    $result = MaintenanceMonitorService::tick(1);
    check($result['failed'] === 1 && !$result['success'], 'Monitor propagates failed sync to summary');
    $scheduled = array_values(array_filter($sql, fn($entry) => str_contains($entry[0], 'last_updates_at = NOW()')));
    $next = strtotime(end($scheduled)[1]['next_due']);
    check($next >= time() + 895 && $next <= time() + 905, 'Failure retries after 15 minutes');
    $syncFails = false;
    $result = MaintenanceMonitorService::tick(1);
    check($result['failed'] === 0 && $result['success'], 'Successful monitor summary');
    $scheduled = array_values(array_filter($sql, fn($entry) => str_contains($entry[0], 'last_updates_at = NOW()')));
    $next = end($scheduled)[1]['next_due'];
    check($next === MaintenanceVerificationSchedule::dueAt(1, null, true), 'Success schedules next configured daily window');
    Settings::$values['maintenance_verification_enabled'] = '0';
    $before = count($requests);
    $result = MaintenanceMonitorService::tick(1);
    check($result['updates'] === 0 && count($requests) === $before, 'Disabled daily schedule sends no synchronization');
    echo 'Commander verification: ' . $checks . " checks passed.\n";
}
